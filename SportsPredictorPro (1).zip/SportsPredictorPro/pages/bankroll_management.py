import streamlit as st
import pandas as pd
import numpy as np
import data_processor
import odds_comparison
import visualization
import utils
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go

def show():
    """
    Display the Bankroll Management page
    """
    st.title("Bankroll Management 💰")
    
    # Get current bankroll data
    bankroll_data = utils.get_bankroll_data()
    
    # Main bankroll information
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            "Current Bankroll", 
            f"${bankroll_data['current_bankroll']:.2f}",
            f"{((bankroll_data['current_bankroll'] / bankroll_data['starting_bankroll']) - 1) * 100:.2f}%"
        )
    
    with col2:
        st.metric(
            "Starting Bankroll", 
            f"${bankroll_data['starting_bankroll']:.2f}"
        )
    
    with col3:
        st.metric(
            "Risk per Bet", 
            f"{bankroll_data['risk_percentage']}%"
        )
    
    # Bankroll management sections
    tab1, tab2, tab3 = st.tabs(["Bankroll Performance", "Bet Calculator", "Betting History"])
    
    with tab1:
        # Bankroll performance over time
        st.subheader("Bankroll Growth Over Time")
        
        # Plot bankroll growth chart
        fig = visualization.plot_bankroll_growth(bankroll_data['history'])
        st.plotly_chart(fig, use_container_width=True)
        
        # Monthly returns
        st.subheader("Monthly Returns")
        
        # Calculate monthly returns from history
        monthly_returns = {}
        sorted_dates = sorted(bankroll_data['history'].keys())
        
        if sorted_dates:
            current_month = None
            month_start_value = None
            
            for date_str in sorted_dates:
                date = datetime.strptime(date_str, "%Y-%m-%d")
                month_key = date.strftime("%Y-%m")
                
                if month_key != current_month:
                    # New month
                    if current_month is not None:
                        # Calculate return for previous month
                        prev_month_end_value = bankroll_data['history'][date_str]
                        monthly_returns[current_month] = ((prev_month_end_value / month_start_value) - 1) * 100
                    
                    # Set new month
                    current_month = month_key
                    month_start_value = bankroll_data['history'][date_str]
            
            # Calculate for last month
            if current_month is not None:
                last_date = sorted_dates[-1]
                last_value = bankroll_data['history'][last_date]
                monthly_returns[current_month] = ((last_value / month_start_value) - 1) * 100
        
        # Display monthly returns
        if monthly_returns:
            monthly_data = []
            for month, return_pct in monthly_returns.items():
                month_date = datetime.strptime(month, "%Y-%m")
                month_name = month_date.strftime("%b %Y")
                monthly_data.append({"Month": month_name, "Return": return_pct})
            
            monthly_df = pd.DataFrame(monthly_data)
            
            # Plot monthly returns
            fig = px.bar(
                monthly_df, 
                x='Month', 
                y='Return',
                text_auto='.2f',
                labels={'Return': 'Return (%)'},
                color='Return',
                color_continuous_scale=['red', 'yellow', 'green'],
                range_color=[-10, 10]
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Insufficient data to calculate monthly returns.")
        
        # Projected growth
        st.subheader("Projected Growth")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            avg_roi = st.number_input("Average ROI per bet (%)", value=5.0, min_value=-50.0, max_value=200.0, step=0.1)
        with col2:
            bets_per_month = st.number_input("Bets per month", value=30, min_value=1, max_value=500, step=1)
        with col3:
            months_ahead = st.number_input("Project months ahead", value=12, min_value=1, max_value=60, step=1)
        
        # Calculate projected growth
        current_bankroll = bankroll_data['current_bankroll']
        risk_pct = bankroll_data['risk_percentage'] / 100
        
        projected_data = []
        projected_bankroll = current_bankroll
        
        for month in range(months_ahead + 1):
            if month == 0:
                # Starting point
                projected_data.append({
                    "Month": f"Current",
                    "Bankroll": projected_bankroll
                })
            else:
                # Calculate monthly growth
                month_roi = (1 + (avg_roi / 100)) ** bets_per_month - 1
                monthly_growth = projected_bankroll * month_roi * risk_pct
                projected_bankroll += monthly_growth
                
                projected_data.append({
                    "Month": f"Month {month}",
                    "Bankroll": projected_bankroll
                })
        
        # Create projection dataframe
        projection_df = pd.DataFrame(projected_data)
        
        # Plot projection
        fig = px.line(
            projection_df,
            x="Month",
            y="Bankroll",
            markers=True,
            labels={"Bankroll": "Projected Bankroll ($)"},
            title="Projected Bankroll Growth"
        )
        
        fig.update_traces(line=dict(width=3))
        fig.add_annotation(
            x=projection_df["Month"].iloc[-1],
            y=projection_df["Bankroll"].iloc[-1],
            text=f"${projection_df['Bankroll'].iloc[-1]:.2f}",
            showarrow=True,
            arrowhead=1
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Projection disclaimer
        st.caption("""
        **Note:** This projection is based on a simplified model and assumes consistent ROI and bet frequency. 
        Actual results will vary based on bet selection, odds, and many other factors.
        """)
    
    with tab2:
        # Bet calculator
        st.subheader("Bet Calculator")
        
        calc_tabs = st.tabs(["Kelly Criterion", "Fixed Percentage", "Arbitrage"])
        
        with calc_tabs[0]:
            # Kelly Criterion calculator
            st.write("""
            The Kelly Criterion is a formula that determines the optimal size of a series of bets to maximize bankroll growth.
            It balances risk and potential return to optimize long-term growth.
            """)
            
            col1, col2 = st.columns(2)
            
            with col1:
                kelly_odds = st.number_input("Decimal Odds", value=2.0, min_value=1.01, max_value=1000.0, step=0.01)
                kelly_prob = st.number_input("Estimated Win Probability (%)", value=50.0, min_value=0.1, max_value=99.9, step=0.1)
                kelly_bankroll = st.number_input("Bankroll ($)", value=bankroll_data['current_bankroll'], min_value=1.0, step=10.0)
            
            with col2:
                # Calculate Kelly stake
                decimal_prob = kelly_prob / 100
                kelly = (decimal_prob * (kelly_odds - 1) - (1 - decimal_prob)) / (kelly_odds - 1)
                
                # Handle negative Kelly (no value bet)
                if kelly <= 0:
                    st.error("No value in this bet according to Kelly Criterion!")
                    st.metric("Kelly Fraction", "0%")
                    st.metric("Recommended Stake", "$0.00")
                    ev = -1 * (1 - decimal_prob) * kelly_bankroll * 0.01  # Expected loss with 1% stake
                    st.metric("Expected Value", f"${ev:.2f}", delta=None)
                else:
                    # Calculate half Kelly (more conservative approach)
                    half_kelly = kelly / 2
                    full_stake = kelly_bankroll * kelly
                    half_stake = kelly_bankroll * half_kelly
                    
                    st.metric("Full Kelly Fraction", f"{kelly*100:.2f}%")
                    st.metric("Half Kelly (Recommended)", f"{half_kelly*100:.2f}%")
                    st.metric("Recommended Stake", f"${half_stake:.2f}")
                    
                    # Calculate expected value
                    ev = decimal_prob * full_stake * (kelly_odds - 1) - (1 - decimal_prob) * full_stake
                    st.metric("Expected Value (Full Kelly)", f"${ev:.2f}", delta=None)
            
            # Kelly explanation
            st.markdown("""
            **How to use Kelly Criterion:**
            - **Probability:** Your estimated probability of winning (must be accurate)
            - **Half Kelly:** Using half of the calculated Kelly stake is recommended to reduce variance
            - **Negative Kelly:** When the calculation is negative, there's no betting value based on your inputs
            """)
        
        with calc_tabs[1]:
            # Fixed percentage calculator
            st.write("""
            The fixed percentage method involves betting a consistent percentage of your bankroll on each wager.
            This approach helps manage risk and ensure long-term sustainability.
            """)
            
            col1, col2 = st.columns(2)
            
            with col1:
                fixed_bankroll = st.number_input("Current Bankroll ($)", value=bankroll_data['current_bankroll'], min_value=1.0, step=10.0, key="fixed_bankroll")
                fixed_pct = st.number_input("Risk Percentage (%)", value=bankroll_data['risk_percentage'], min_value=0.1, max_value=25.0, step=0.1)
                fixed_odds = st.number_input("Decimal Odds", value=2.0, min_value=1.01, max_value=1000.0, step=0.01, key="fixed_odds")
            
            with col2:
                # Calculate stake
                fixed_stake = fixed_bankroll * (fixed_pct / 100)
                potential_return = fixed_stake * fixed_odds
                potential_profit = potential_return - fixed_stake
                
                st.metric("Recommended Stake", f"${fixed_stake:.2f}")
                st.metric("Potential Return", f"${potential_return:.2f}")
                st.metric("Potential Profit", f"${potential_profit:.2f}")
                
                # Update button
                if st.button("Update Default Risk %"):
                    bankroll_data['risk_percentage'] = fixed_pct
                    st.session_state.bankroll = bankroll_data
                    st.success(f"Default risk percentage updated to {fixed_pct}%")
        
        with calc_tabs[2]:
            # Arbitrage calculator
            st.write("""
            Arbitrage betting involves placing bets on all possible outcomes of an event with different bookmakers,
            guaranteeing a profit regardless of the outcome.
            """)
            
            col1, col2 = st.columns(2)
            
            with col1:
                arb_bankroll = st.number_input("Available Bankroll ($)", value=bankroll_data['current_bankroll'], min_value=1.0, step=10.0, key="arb_bankroll")
                outcome1_odds = st.number_input("Outcome 1 Odds", value=1.95, min_value=1.01, max_value=1000.0, step=0.01)
                outcome2_odds = st.number_input("Outcome 2 Odds", value=2.05, min_value=1.01, max_value=1000.0, step=0.01)
                
                # Option for 3-way markets
                include_draw = st.checkbox("Include Draw (3-way market)")
                outcome3_odds = None
                if include_draw:
                    outcome3_odds = st.number_input("Draw Odds", value=3.25, min_value=1.01, max_value=1000.0, step=0.01)
            
            with col2:
                # Calculate arbitrage
                if include_draw and outcome3_odds:
                    # 3-way market calculation
                    implied_prob1 = 1 / outcome1_odds
                    implied_prob2 = 1 / outcome2_odds
                    implied_prob3 = 1 / outcome3_odds
                    total_implied_prob = implied_prob1 + implied_prob2 + implied_prob3
                    
                    if total_implied_prob < 1:
                        # Arbitrage opportunity exists
                        arb_pct = (1 - total_implied_prob) / total_implied_prob * 100
                        
                        # Calculate stakes
                        stake1 = arb_bankroll * (implied_prob1 / total_implied_prob)
                        stake2 = arb_bankroll * (implied_prob2 / total_implied_prob)
                        stake3 = arb_bankroll * (implied_prob3 / total_implied_prob)
                        
                        # Calculate profit
                        profit = arb_bankroll / total_implied_prob - arb_bankroll
                        
                        st.success(f"Arbitrage Opportunity: {arb_pct:.2f}% profit")
                        st.metric("Stake for Outcome 1", f"${stake1:.2f}")
                        st.metric("Stake for Outcome 2", f"${stake2:.2f}")
                        st.metric("Stake for Draw", f"${stake3:.2f}")
                        st.metric("Guaranteed Profit", f"${profit:.2f}")
                    else:
                        st.error("No arbitrage opportunity with these odds")
                        st.write(f"Total implied probability: {total_implied_prob:.4f} (must be < 1 for arbitrage)")
                else:
                    # 2-way market calculation
                    implied_prob1 = 1 / outcome1_odds
                    implied_prob2 = 1 / outcome2_odds
                    total_implied_prob = implied_prob1 + implied_prob2
                    
                    if total_implied_prob < 1:
                        # Arbitrage opportunity exists
                        arb_pct = (1 - total_implied_prob) / total_implied_prob * 100
                        
                        # Calculate stakes
                        stake1 = arb_bankroll * (implied_prob1 / total_implied_prob)
                        stake2 = arb_bankroll * (implied_prob2 / total_implied_prob)
                        
                        # Calculate profit
                        profit = arb_bankroll / total_implied_prob - arb_bankroll
                        
                        st.success(f"Arbitrage Opportunity: {arb_pct:.2f}% profit")
                        st.metric("Stake for Outcome 1", f"${stake1:.2f}")
                        st.metric("Stake for Outcome 2", f"${stake2:.2f}")
                        st.metric("Guaranteed Profit", f"${profit:.2f}")
                    else:
                        st.error("No arbitrage opportunity with these odds")
                        st.write(f"Total implied probability: {total_implied_prob:.4f} (must be < 1 for arbitrage)")
            
            # Arbitrage explanation
            st.markdown("""
            **How arbitrage betting works:**
            - Find odds at different bookmakers where the combined implied probability is less than 1
            - Calculate the optimal stake for each outcome
            - Place bets according to the calculated stakes
            - Profit is guaranteed regardless of the outcome

            **Note:** Arbitrage opportunities are rare and often short-lived. Bookmakers actively try to eliminate them.
            """)
    
    with tab3:
        # Betting history
        st.subheader("Betting History")
        
        # Simulated betting history
        if 'bets' not in bankroll_data or len(bankroll_data['bets']) == 0:
            # Create sample betting history if none exists
            sample_bets = [
                {
                    "timestamp": (datetime.now() - timedelta(days=20)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Soccer",
                    "event": "Manchester United vs Liverpool",
                    "bet_type": "Home Win",
                    "odds": 2.10,
                    "stake": 20.00,
                    "result": "Win",
                    "profit": 21.00,
                    "bankroll_after": 1021.00
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=18)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Basketball",
                    "event": "LA Lakers vs Chicago Bulls",
                    "bet_type": "Away Win",
                    "odds": 2.45,
                    "stake": 20.42,
                    "result": "Loss",
                    "profit": -20.42,
                    "bankroll_after": 1000.58
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Rugby",
                    "event": "New Zealand vs South Africa",
                    "bet_type": "Away Win",
                    "odds": 3.00,
                    "stake": 20.01,
                    "result": "Win",
                    "profit": 40.02,
                    "bankroll_after": 1040.60
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Cricket",
                    "event": "India vs Australia",
                    "bet_type": "Home Win",
                    "odds": 1.85,
                    "stake": 20.81,
                    "result": "Win",
                    "profit": 17.69,
                    "bankroll_after": 1058.29
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Horse Racing",
                    "event": "Royal Ascot - Race 3",
                    "bet_type": "Win",
                    "odds": 6.50,
                    "stake": 21.17,
                    "result": "Loss",
                    "profit": -21.17,
                    "bankroll_after": 1037.12
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Soccer",
                    "event": "Arsenal vs Chelsea",
                    "bet_type": "Draw",
                    "odds": 3.40,
                    "stake": 20.74,
                    "result": "Win",
                    "profit": 49.78,
                    "bankroll_after": 1086.90
                },
                {
                    "timestamp": (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": "Volleyball",
                    "event": "Brazil vs Italy",
                    "bet_type": "Home Win",
                    "odds": 1.65,
                    "stake": 21.74,
                    "result": "Win",
                    "profit": 14.13,
                    "bankroll_after": 1101.03
                }
            ]
            
            # Add sample bets to bankroll data
            bankroll_data['bets'] = sample_bets
            st.session_state.bankroll = bankroll_data
        
        # Display betting history
        if bankroll_data['bets']:
            # Filter options
            col1, col2 = st.columns(2)
            with col1:
                sport_filter = st.selectbox(
                    "Filter by Sport",
                    ["All Sports", "Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"]
                )
            with col2:
                result_filter = st.selectbox(
                    "Filter by Result",
                    ["All Results", "Win", "Loss"]
                )
            
            # Apply filters
            filtered_bets = bankroll_data['bets']
            if sport_filter != "All Sports":
                filtered_bets = [bet for bet in filtered_bets if bet['sport'] == sport_filter]
            if result_filter != "All Results":
                filtered_bets = [bet for bet in filtered_bets if bet['result'] == result_filter]
            
            # Create DataFrame from bets
            if filtered_bets:
                bets_df = pd.DataFrame(filtered_bets)
                
                # Sort by timestamp (most recent first)
                bets_df = bets_df.sort_values(by='timestamp', ascending=False)
                
                # Format profit column with colors
                st.dataframe(
                    bets_df[['timestamp', 'sport', 'event', 'bet_type', 'odds', 'stake', 'result', 'profit']],
                    hide_index=True,
                    use_container_width=True
                )
                
                # Betting stats
                total_bets = len(filtered_bets)
                winning_bets = len([bet for bet in filtered_bets if bet['result'] == 'Win'])
                win_rate = (winning_bets / total_bets) * 100 if total_bets > 0 else 0
                total_staked = sum(bet['stake'] for bet in filtered_bets)
                total_profit = sum(bet['profit'] for bet in filtered_bets)
                roi = (total_profit / total_staked) * 100 if total_staked > 0 else 0
                
                # Display stats
                st.subheader("Betting Statistics")
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Total Bets", total_bets)
                with col2:
                    st.metric("Win Rate", f"{win_rate:.1f}%")
                with col3:
                    st.metric("Total Staked", f"${total_staked:.2f}")
                with col4:
                    st.metric("Total Profit", f"${total_profit:.2f}", f"{roi:.1f}% ROI")
                
                # Distribution of bet types
                sport_counts = {}
                for bet in filtered_bets:
                    sport = bet['sport']
                    if sport not in sport_counts:
                        sport_counts[sport] = 0
                    sport_counts[sport] += 1
                
                # Create sport distribution chart
                if sport_counts:
                    st.subheader("Distribution of Bets by Sport")
                    
                    fig = px.pie(
                        values=list(sport_counts.values()),
                        names=list(sport_counts.keys()),
                        hole=0.4
                    )
                    fig.update_traces(textinfo='percent+label')
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                # Kelly distribution
                st.subheader("Kelly Distribution Analysis")
                
                # Calculate Kelly values for each bet
                kelly_values = []
                for bet in filtered_bets:
                    # Assuming the win probability was approximately aligned with the odds
                    odds = bet['odds']
                    implied_prob = 0.85 / odds  # Slight adjustment since bookmakers build in margin
                    
                    kelly = (implied_prob * (odds - 1) - (1 - implied_prob)) / (odds - 1)
                    
                    if kelly > -0.5:  # Filter extreme negative values
                        kelly_values.append(kelly)
                
                # Plot Kelly distribution
                if kelly_values:
                    fig = visualization.plot_kelly_criterion_distribution(kelly_values)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    st.markdown("""
                    **Kelly Distribution Analysis:**
                    - **Red zone (negative):** Bets with negative expected value
                    - **Yellow zone (0-5%):** Small edges, conservative bets
                    - **Green zone (5-20%):** Ideal betting opportunities with good value
                    - **Red zone (>20%):** Extremely high value but potential miscalculation
                    
                    For optimal bankroll growth, focus on bets in the green zone.
                    """)
            else:
                st.info("No bets found with the selected filters.")
        else:
            st.info("No betting history available.")
    
    # Update bankroll section
    st.markdown("---")
    st.subheader("Update Bankroll")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Deposit/withdraw
        st.write("Deposit or Withdraw Funds")
        
        amount = st.number_input("Amount ($)", value=0.0, step=10.0)
        transaction_type = st.radio("Transaction Type", ["Deposit", "Withdraw"], horizontal=True)
        
        if st.button("Update Balance"):
            if transaction_type == "Withdraw" and amount > bankroll_data['current_bankroll']:
                st.error("Insufficient funds for withdrawal")
            else:
                if transaction_type == "Deposit":
                    bankroll_data['current_bankroll'] += amount
                    st.success(f"${amount:.2f} deposited successfully")
                else:
                    bankroll_data['current_bankroll'] -= amount
                    st.success(f"${amount:.2f} withdrawn successfully")
                
                # Update history
                today = datetime.now().strftime("%Y-%m-%d")
                bankroll_data['history'][today] = bankroll_data['current_bankroll']
                
                # Update session state
                st.session_state.bankroll = bankroll_data
    
    with col2:
        # Manual bet result entry
        st.write("Record Manual Bet Result")
        
        bet_sport = st.selectbox("Sport", ["Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"])
        bet_event = st.text_input("Event", placeholder="Team A vs Team B")
        bet_type = st.text_input("Bet Type", placeholder="Home Win, Over 2.5, etc.")
        bet_odds = st.number_input("Odds", value=2.0, min_value=1.01, step=0.01)
        bet_stake = st.number_input("Stake ($)", value=round(bankroll_data['current_bankroll'] * (bankroll_data['risk_percentage'] / 100), 2), min_value=0.01, step=1.0)
        bet_result = st.radio("Result", ["Win", "Loss"], horizontal=True)
        
        if st.button("Record Bet"):
            if not bet_event or not bet_type:
                st.error("Please fill in all fields")
            elif bet_stake > bankroll_data['current_bankroll']:
                st.error("Stake cannot exceed current bankroll")
            else:
                # Calculate profit
                profit = bet_stake * (bet_odds - 1) if bet_result == "Win" else -bet_stake
                
                # Update bankroll
                bankroll_data['current_bankroll'] += profit
                
                # Update history
                today = datetime.now().strftime("%Y-%m-%d")
                bankroll_data['history'][today] = bankroll_data['current_bankroll']
                
                # Add bet to history
                new_bet = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "sport": bet_sport,
                    "event": bet_event,
                    "bet_type": bet_type,
                    "odds": bet_odds,
                    "stake": bet_stake,
                    "result": bet_result,
                    "profit": profit,
                    "bankroll_after": bankroll_data['current_bankroll']
                }
                
                if 'bets' not in bankroll_data:
                    bankroll_data['bets'] = []
                
                bankroll_data['bets'].append(new_bet)
                
                # Update session state
                st.session_state.bankroll = bankroll_data
                
                st.success(f"Bet recorded successfully. Profit: ${profit:.2f}")
