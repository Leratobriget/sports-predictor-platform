import streamlit as st
import pandas as pd
import numpy as np
import data_processor
import prediction_models
import odds_comparison
import visualization
import utils
from datetime import datetime, timedelta

def show():
    """
    Display the Soccer prediction page
    """
    st.title("Soccer Predictions ⚽")
    
    # Check API keys
    utils.check_api_keys()
    
    if st.session_state.api_error:
        st.warning(st.session_state.api_error)
    
    # Competitions filter
    competitions = [
        "English Premier League",
        "Spanish La Liga",
        "German Bundesliga",
        "Italian Serie A",
        "French Ligue 1",
        "UEFA Champions League",
        "UEFA Europa League",
        "All Competitions"
    ]
    
    selected_competition = st.selectbox("Select Competition", competitions, index=0)
    
    # Date range selection
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input(
            "From date",
            datetime.now().date(),
            min_value=datetime.now().date(),
            max_value=datetime.now().date() + timedelta(days=30)
        )
    with col2:
        end_date = st.date_input(
            "To date",
            datetime.now().date() + timedelta(days=7),
            min_value=start_date,
            max_value=datetime.now().date() + timedelta(days=30)
        )
    
    # Get fixtures for the date range
    with st.spinner("Loading fixtures..."):
        all_fixtures = []
        current_date = start_date
        
        while current_date <= end_date:
            daily_fixtures = data_processor.get_upcoming_matches("Soccer", current_date)
            if daily_fixtures:
                all_fixtures.extend(daily_fixtures)
            current_date += timedelta(days=1)
        
        # Filter by competition if not "All Competitions"
        if selected_competition != "All Competitions":
            all_fixtures = [f for f in all_fixtures if f.get('competition', '') == selected_competition]
    
    if not all_fixtures:
        st.info(f"No fixtures found for the selected date range and competition.")
    else:
        st.subheader(f"Upcoming Soccer Fixtures")
        
        # Group fixtures by date
        fixtures_by_date = {}
        for fixture in all_fixtures:
            date = fixture['date']
            if date not in fixtures_by_date:
                fixtures_by_date[date] = []
            fixtures_by_date[date].append(fixture)
        
        # Display fixtures by date
        for date, fixtures in fixtures_by_date.items():
            st.markdown(f"### {date}")
            
            # Create a table of fixtures
            fixture_data = []
            for f in fixtures:
                fixture_data.append({
                    "Time": f.get('time', 'TBA'),
                    "Home": f['home_team'],
                    "Away": f['away_team'],
                    "Competition": f.get('competition', 'Unknown')
                })
            
            if fixture_data:
                df = pd.DataFrame(fixture_data)
                st.dataframe(df, hide_index=True, use_container_width=True)
            
            # Analyze buttons for each fixture
            cols = st.columns(len(fixtures))
            for i, fixture in enumerate(fixtures):
                with cols[i]:
                    if st.button(f"Analyze Match", key=f"analyze_{date}_{i}"):
                        st.session_state.selected_match = fixture
                        st.session_state.match_analysis = True
        
        # Match analysis section
        if 'match_analysis' in st.session_state and st.session_state.match_analysis:
            match = st.session_state.selected_match
            st.markdown("---")
            st.subheader(f"Match Analysis: {match['home_team']} vs {match['away_team']}")
            st.caption(f"{match.get('date', 'Date TBA')} | {match.get('time', 'Time TBA')} | {match.get('competition', 'Competition')}")
            
            # Match tabs
            tab1, tab2, tab3, tab4 = st.tabs(["Prediction", "Odds Comparison", "Team Stats", "Historical Matchups"])
            
            with tab1:
                # Prediction details
                with st.spinner("Generating prediction..."):
                    prediction = prediction_models.predict_match("Soccer", match)
                    
                    if prediction:
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Home Win", f"{prediction['home_win_prob']:.1f}%")
                        with col2:
                            st.metric("Draw", f"{prediction['draw_prob']:.1f}%")
                        with col3:
                            st.metric("Away Win", f"{prediction['away_win_prob']:.1f}%")
                        
                        # Visualization of probabilities
                        fig_data = {
                            'Outcome': ['Home Win', 'Draw', 'Away Win'],
                            'Probability': [
                                prediction['home_win_prob'],
                                prediction['draw_prob'],
                                prediction['away_win_prob']
                            ]
                        }
                        df = pd.DataFrame(fig_data)
                        st.bar_chart(df, x='Outcome', y='Probability', use_container_width=True)
                        
                        st.subheader("Prediction Confidence")
                        st.progress(prediction['confidence'] / 100)
                        st.write(f"Confidence: {prediction['confidence']}%")
                        
                        st.markdown("### Key Factors")
                        for factor in prediction['key_factors']:
                            st.write(f"- {factor}")
                        
                        # Save prediction button
                        if st.button("Save Prediction"):
                            prediction_data = {
                                'sport': "Soccer",
                                'match': f"{match['home_team']} vs {match['away_team']}",
                                'date': match['date'],
                                'prediction': prediction
                            }
                            utils.save_prediction(prediction_data)
                            st.success("Prediction saved successfully!")
                    else:
                        st.info("Insufficient data to generate prediction.")
            
            with tab2:
                # Odds comparison
                with st.spinner("Comparing odds across sportsbooks..."):
                    odds_data = odds_comparison.get_odds_comparison("Soccer", match)
                    
                    if odds_data and len(odds_data) > 0:
                        st.subheader("Odds Comparison")
                        
                        # Odds format selection
                        odds_format = st.radio(
                            "Odds Format",
                            ["Decimal", "Fractional", "American"],
                            horizontal=True
                        )
                        
                        # Convert odds format based on selection
                        formatted_odds_data = []
                        for bookie_odds in odds_data:
                            formatted_odds = bookie_odds.copy()
                            
                            if odds_format == "Decimal":
                                # Already in decimal format
                                pass
                            elif odds_format == "Fractional":
                                formatted_odds['home_win'] = utils.convert_odds_format(bookie_odds['home_win'], "fractional")
                                formatted_odds['draw'] = utils.convert_odds_format(bookie_odds['draw'], "fractional")
                                formatted_odds['away_win'] = utils.convert_odds_format(bookie_odds['away_win'], "fractional")
                            elif odds_format == "American":
                                formatted_odds['home_win'] = utils.convert_odds_format(bookie_odds['home_win'], "american")
                                formatted_odds['draw'] = utils.convert_odds_format(bookie_odds['draw'], "american")
                                formatted_odds['away_win'] = utils.convert_odds_format(bookie_odds['away_win'], "american")
                            
                            formatted_odds_data.append(formatted_odds)
                        
                        # Convert to DataFrame for better display
                        odds_df = pd.DataFrame(formatted_odds_data)
                        st.dataframe(odds_df[['bookmaker', 'home_win', 'draw', 'away_win']], hide_index=True)
                        
                        # Best odds highlighted
                        st.subheader("Best Available Odds")
                        best_odds = odds_comparison.get_best_odds(odds_data)
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric(
                                f"{match['home_team']} Win", 
                                utils.format_odds(best_odds['home_win']['odds']), 
                                f"at {best_odds['home_win']['bookmaker']}"
                            )
                        with col2:
                            st.metric(
                                f"Draw", 
                                utils.format_odds(best_odds['draw']['odds']), 
                                f"at {best_odds['draw']['bookmaker']}"
                            )
                        with col3:
                            st.metric(
                                f"{match['away_team']} Win", 
                                utils.format_odds(best_odds['away_win']['odds']), 
                                f"at {best_odds['away_win']['bookmaker']}"
                            )
                        
                        # Value bets
                        st.subheader("Value Bet Analysis")
                        value_bets = odds_comparison.identify_value_bets(odds_data, prediction)
                        
                        if value_bets and len(value_bets) > 0:
                            for bet in value_bets:
                                st.write(f"- {bet['description']} ({bet['value_percentage']:.1f}% edge)")
                                
                                # Calculate bankroll data
                                bankroll_data = utils.get_bankroll_data()
                                stake = utils.calculate_bet_amount(
                                    bankroll_data['current_bankroll'],
                                    bankroll_data['risk_percentage']
                                )
                                
                                # Show potential return
                                potential_return = stake * bet['odds']
                                potential_profit = potential_return - stake
                                
                                st.caption(f"Recommended stake: ${stake:.2f} | Potential return: ${potential_return:.2f} | Potential profit: ${potential_profit:.2f}")
                                
                                # Place bet button (simulated)
                                if st.button(f"Place bet", key=f"place_bet_{bet['bet_type']}"):
                                    st.success(f"Bet placed: ${stake:.2f} on {bet['bet_type']} at odds of {bet['odds']}")
                                    # In a real app, this would integrate with a betting platform
                        else:
                            st.write("No significant value bets identified for this match.")
                    else:
                        st.info("No odds data available for this match.")
            
            with tab3:
                # Team stats
                with st.spinner("Loading team statistics..."):
                    home_stats = data_processor.get_team_stats("Soccer", match['home_team'])
                    away_stats = data_processor.get_team_stats("Soccer", match['away_team'])
                    
                    if home_stats and away_stats:
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader(f"{match['home_team']} Stats")
                            visualization.display_team_stats(home_stats)
                        
                        with col2:
                            st.subheader(f"{match['away_team']} Stats")
                            visualization.display_team_stats(away_stats)
                        
                        # Home/Away form
                        st.subheader("Home vs Away Form")
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write(f"{match['home_team']} Home Form:")
                            home_form = home_stats.get('home_form', [])
                            # Create a more visually appealing form display
                            html_form = ""
                            for result in home_form:
                                if result == 'W':
                                    html_form += f'<span style="background-color:#28a745;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">W</span>'
                                elif result == 'D':
                                    html_form += f'<span style="background-color:#ffc107;color:black;padding:2px 8px;border-radius:3px;margin-right:5px;">D</span>'
                                elif result == 'L':
                                    html_form += f'<span style="background-color:#dc3545;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">L</span>'
                            
                            st.markdown(html_form, unsafe_allow_html=True)
                            
                            st.write(f"Home Record: {home_stats.get('home_record', 'N/A')}")
                        
                        with col2:
                            st.write(f"{match['away_team']} Away Form:")
                            away_form = away_stats.get('away_form', [])
                            # Create a more visually appealing form display
                            html_form = ""
                            for result in away_form:
                                if result == 'W':
                                    html_form += f'<span style="background-color:#28a745;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">W</span>'
                                elif result == 'D':
                                    html_form += f'<span style="background-color:#ffc107;color:black;padding:2px 8px;border-radius:3px;margin-right:5px;">D</span>'
                                elif result == 'L':
                                    html_form += f'<span style="background-color:#dc3545;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">L</span>'
                            
                            st.markdown(html_form, unsafe_allow_html=True)
                            
                            st.write(f"Away Record: {away_stats.get('away_record', 'N/A')}")
                        
                        # Head-to-head comparison
                        st.subheader("Head-to-Head Comparison")
                        visualization.compare_team_stats(home_stats, away_stats, match)
                    else:
                        st.info("Team statistics not available.")
            
            with tab4:
                # Historical matchups
                with st.spinner("Loading historical matchups..."):
                    historical_matches = data_processor.get_historical_matchups(
                        "Soccer", match['home_team'], match['away_team']
                    )
                    
                    if historical_matches and len(historical_matches) > 0:
                        st.subheader(f"Previous {match['home_team']} vs {match['away_team']} Matches")
                        
                        # Create a table of historical results
                        hist_data = []
                        for h_match in historical_matches:
                            result = ""
                            if h_match['home_team'] == match['home_team']:
                                if h_match['home_score'] > h_match['away_score']:
                                    result = f"{match['home_team']} Win"
                                elif h_match['home_score'] < h_match['away_score']:
                                    result = f"{match['away_team']} Win"
                                else:
                                    result = "Draw"
                            else:
                                if h_match['home_score'] > h_match['away_score']:
                                    result = f"{h_match['home_team']} Win"
                                elif h_match['home_score'] < h_match['away_score']:
                                    result = f"{h_match['away_team']} Win"
                                else:
                                    result = "Draw"
                            
                            hist_data.append({
                                "Date": h_match['date'],
                                "Home Team": h_match['home_team'],
                                "Score": f"{h_match['home_score']} - {h_match['away_score']}",
                                "Away Team": h_match['away_team'],
                                "Result": result
                            })
                        
                        hist_df = pd.DataFrame(hist_data)
                        st.dataframe(hist_df, hide_index=True, use_container_width=True)
                        
                        # Visualization of historical matchups
                        visualization.plot_historical_matchups(historical_matches)
                        
                        # Home/Away advantage analysis
                        st.subheader("Home/Away Advantage Analysis")
                        home_away_stats = data_processor.get_home_away_advantage("Soccer")
                        
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Home Win %", f"{home_away_stats.get('home_win_percentage', 0):.1f}%")
                        with col2:
                            st.metric("Draw %", f"{home_away_stats.get('draw_percentage', 0):.1f}%")
                        with col3:
                            st.metric("Away Win %", f"{home_away_stats.get('away_win_percentage', 0):.1f}%")
                        
                        st.caption("Average across all matches in similar competitions")
                    else:
                        st.info("No historical matchups found between these teams.")
    
    # Footer with additional information
    st.markdown("---")
    st.markdown("""
    ### About Soccer Predictions
    
    Our soccer prediction model takes into account:
    - Team form and performance metrics
    - Head-to-head history
    - Home/away advantage
    - Player availability and injuries (when data is available)
    - League-specific patterns and trends
    
    For best results, use these predictions as one factor in your betting decisions, along with your own research and analysis.
    """)
