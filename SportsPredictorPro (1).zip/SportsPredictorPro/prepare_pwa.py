import os
import shutil
import json

def add_pwa_support():
    """
    Add Progressive Web App (PWA) support to the Streamlit app
    """
    # Create .streamlit/static directory if it doesn't exist
    static_dir = os.path.join('.streamlit', 'static')
    os.makedirs(static_dir, exist_ok=True)
    
    # Create the manifest.json file if it doesn't exist
    manifest_path = os.path.join(static_dir, 'manifest.json')
    if not os.path.exists(manifest_path):
        manifest = {
            "name": "Sports Prediction Platform",
            "short_name": "PredictSports",
            "description": "A multi-sport prediction platform for analyzing game outcomes and comparing odds across sportsbooks",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#ffffff",
            "theme_color": "#1E88E5",
            "icons": [
                {
                    "src": "icon-192.png",
                    "sizes": "192x192",
                    "type": "image/png",
                    "purpose": "any maskable"
                },
                {
                    "src": "icon-512.png",
                    "sizes": "512x512",
                    "type": "image/png",
                    "purpose": "any maskable"
                }
            ],
            "shortcuts": [
                {
                    "name": "Soccer Predictions",
                    "url": "/?page=Soccer",
                    "icons": [{ "src": "icon-192.png", "sizes": "192x192" }]
                },
                {
                    "name": "Basketball Predictions",
                    "url": "/?page=Basketball",
                    "icons": [{ "src": "icon-192.png", "sizes": "192x192" }]
                }
            ],
            "related_applications": [],
            "prefer_related_applications": False
        }
        
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        print(f"Created manifest.json at {manifest_path}")
    
    # Create service-worker.js file if it doesn't exist
    service_worker_path = os.path.join(static_dir, 'service-worker.js')
    if not os.path.exists(service_worker_path):
        service_worker = """// Service Worker for Sports Prediction Platform
const CACHE_NAME = 'sports-prediction-cache-v1';

// Files to cache
const urlsToCache = [
  '/',
  '/static/icon-192.png',
  '/static/icon-512.png',
  '/static/manifest.json',
  '/static/offline.html'
];

// Install event - cache assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event - respond with cache then network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return the response
        if (response) {
          return response;
        }
        
        // Clone the request
        const fetchRequest = event.request.clone();
        
        return fetch(fetchRequest)
          .then(response => {
            // Check if valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clone the response
            const responseToCache = response.clone();
            
            // Cache the response
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
              
            return response;
          })
          .catch(error => {
            // Offline fallback
            if (event.request.mode === 'navigate') {
              return caches.match('/static/offline.html');
            }
          });
      })
  );
});

// Push event - handle notifications
self.addEventListener('push', event => {
  if (event.data) {
    const data = event.data.json();
    
    const options = {
      body: data.body || 'New betting opportunity available!',
      icon: '/static/icon-192.png',
      badge: '/static/icon-192.png',
      vibrate: [100, 50, 100],
      data: {
        url: data.url || '/'
      }
    };
    
    event.waitUntil(
      self.registration.showNotification(
        data.title || 'Sports Prediction Alert',
        options
      )
    );
  }
});

// Notification click event - open the app
self.addEventListener('notificationclick', event => {
  event.notification.close();
  
  const url = event.notification.data.url;
  
  event.waitUntil(
    clients.matchAll({type: 'window'})
      .then(windowClients => {
        // Check if there's already a window and focus it
        for (const client of windowClients) {
          if (client.url === url && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Otherwise open a new window
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
  );
});
"""
        
        with open(service_worker_path, 'w') as f:
            f.write(service_worker)
        
        print(f"Created service-worker.js at {service_worker_path}")
    
    # Create offline.html file if it doesn't exist
    offline_path = os.path.join(static_dir, 'offline.html')
    if not os.path.exists(offline_path):
        offline_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offline - Sports Prediction Platform</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
            text-align: center;
        }
        .offline-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            max-width: 90%;
            width: 500px;
        }
        h1 {
            color: #1E88E5;
            margin-top: 0;
        }
        .icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        button {
            background-color: #1E88E5;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background-color: #1976D2;
        }
    </style>
</head>
<body>
    <div class="offline-container">
        <div class="icon">📡</div>
        <h1>You're Offline</h1>
        <p>The Sports Prediction Platform requires an internet connection to provide you with the latest odds and predictions.</p>
        <p>Please check your connection and try again.</p>
        <button onclick="window.location.reload()">Try Again</button>
    </div>
</body>
</html>"""
        
        with open(offline_path, 'w') as f:
            f.write(offline_html)
        
        print(f"Created offline.html at {offline_path}")
    
    print("\nPWA support has been added to your Streamlit app!")
    print("To complete the setup, you'll need to:")
    print("1. Add app icons (icon-192.png and icon-512.png) to the .streamlit/static directory")
    print("2. Add the PWA registration script to your Streamlit app")
    print("3. Deploy your app to a HTTPS-enabled host")

if __name__ == "__main__":
    add_pwa_support()