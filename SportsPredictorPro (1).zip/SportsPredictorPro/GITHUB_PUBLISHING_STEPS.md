# Step-by-Step Publishing Guide for GitHub Pages

Follow these improved instructions to publish your Sports Prediction Platform to GitHub Pages:

## Step 1: Run the Preparation Script First

1. Make sure to run the preparation script in Replit:
   ```
   python prepare_for_github.py
   ```
2. This will create the necessary files in the `/docs` directory

## Step 2: Download Your Code

1. In Replit, click the three dots (...) next to "Files" in the sidebar
2. Select "Download as zip" to download all your project files
3. Extract the zip file to a folder on your computer

## Step 3: Create a GitHub Repository

1. Go to [GitHub.com](https://github.com) and sign in with your account (username: Leratobriget)
2. Click the "+" button in the top-right corner and select "New repository"
3. Name your repository: `sports-prediction-platform`
4. Set it to Public
5. Do NOT initialize with a README, .gitignore, or license (we have our own files)
6. Click "Create repository"

## Step 4: Upload Your Code to GitHub

### Option 1: Using GitHub's Web Interface (Easiest)

1. On your empty repository page, click "uploading an existing file"
2. Drag and drop all the files from your extracted folder
3. Make sure to include the `/docs` folder and all its contents
4. Click "Commit changes" at the bottom of the page

### Option 2: Using Git Command Line (For Advanced Users)

```bash
# Extract your downloaded zip file
# Open a terminal/command prompt in the extracted folder
git init
git add .
git commit -m "Initial commit"
git branch -M main  # Or use "master" if you prefer
git remote add origin https://github.com/Leratobriget/sports-prediction-platform.git
git push -u origin main  # Change to "master" if you used that above
```

## Step 5: Enable GitHub Pages

1. On your repository page, click "Settings"
2. In the left sidebar, click "Pages"
3. Under "Build and deployment", set:
   - Source: "Deploy from a branch"
   - Branch: Select your branch name ("main" or "master")
   - Folder: Select "/docs"
4. Click "Save"
5. Wait 5-10 minutes for GitHub to deploy your site

## Step 6: Access Your Landing Page

Your landing page will be available at: https://Leratobriget.github.io/sports-prediction-platform/

This is a simple landing page that explains your project. The actual Streamlit app cannot run directly on GitHub Pages because it requires a Python server.

## Step 7: Install as a Mobile App (PWA Demo)

The landing page can be installed as a Progressive Web App to demonstrate the PWA capabilities:

### On Android:
1. Open the URL in Chrome
2. Tap the menu (three dots)
3. Select "Add to Home Screen"

### On iOS:
1. Open the URL in Safari
2. Tap the Share button
3. Select "Add to Home Screen"

## Troubleshooting

### If your deployment fails:

1. **Check branch names**: Make sure you're using the same branch name in GitHub Pages settings as your actual branch ("main" or "master")
2. **Verify the docs folder**: Ensure the `/docs` folder was uploaded with all its contents
3. **Try GitHub Actions**: If normal deployment fails, try using GitHub Actions:
   - Go to "Settings" > "Pages"
   - Change Source to "GitHub Actions"
   - Select "Static HTML" workflow
4. **Check for errors**: Look at the "Actions" tab in your repository to see specific error messages
5. **Service worker path**: If you get a 404 for service-worker.js, check that it's using a relative path ('./service-worker.js')