import streamlit as st
import pandas as pd
import numpy as np
import data_processor
import prediction_models
import odds_comparison
import visualization
import utils
from datetime import datetime, timedelta

def show():
    """
    Display the Horse Racing prediction page
    """
    st.title("Horse Racing Predictions 🏇")
    
    # Check API keys
    utils.check_api_keys()
    
    if st.session_state.api_error:
        st.warning(st.session_state.api_error)
    
    # Racetracks filter
    racetracks = [
        "Churchill Downs",
        "Flemington",
        "Ascot",
        "Meydan",
        "Aintree",
        "Santa Anita Park",
        "All Racetracks"
    ]
    
    selected_track = st.selectbox("Select Racetrack", racetracks, index=6)
    
    # Date selection
    selected_date = st.date_input(
        "Race date",
        datetime.now().date(),
        min_value=datetime.now().date(),
        max_value=datetime.now().date() + timedelta(days=30)
    )
    
    # Get race cards for the selected date
    with st.spinner("Loading race cards..."):
        races = data_processor.get_upcoming_matches("Horse Racing", selected_date)
        
        # Filter by racetrack if not "All Racetracks"
        if selected_track != "All Racetracks":
            races = [r for r in races if r.get('venue', '') == selected_track]
    
    if not races:
        st.info(f"No races found for the selected date and racetrack.")
    else:
        st.subheader(f"Upcoming Horse Races")
        
        # Group races by venue
        races_by_venue = {}
        for race in races:
            venue = race.get('venue', 'Unknown Venue')
            if venue not in races_by_venue:
                races_by_venue[venue] = []
            races_by_venue[venue].append(race)
        
        # Display races by venue
        for venue, venue_races in races_by_venue.items():
            st.markdown(f"### {venue}")
            
            # Create a table of races
            race_data = []
            for r in venue_races:
                race_data.append({
                    "Time": r.get('time', 'TBA'),
                    "Race Name": r.get('race_name', 'Unnamed Race'),
                    "Distance": r.get('distance', 'Unknown')
                })
            
            if race_data:
                df = pd.DataFrame(race_data)
                st.dataframe(df, hide_index=True, use_container_width=True)
            
            # Analyze buttons for each race
            for i, race in enumerate(venue_races):
                if st.button(f"View Race Card: {race.get('race_name', f'Race {i+1}')}", key=f"race_{venue}_{i}"):
                    st.session_state.selected_race = race
                    st.session_state.race_analysis = True
        
        # Race analysis section
        if 'race_analysis' in st.session_state and st.session_state.race_analysis:
            race = st.session_state.selected_race
            st.markdown("---")
            st.subheader(f"Race Analysis: {race.get('race_name', 'Race')}")
            st.caption(f"{race.get('date', 'Date TBA')} | {race.get('time', 'Time TBA')} | {race.get('venue', 'Venue')} | {race.get('distance', 'Distance')}")
            
            # Simulated runners for the race
            runners = [
                {"number": 1, "name": "Thunderbolt", "jockey": "J. Smith", "trainer": "T. Johnson", "weight": "58kg", "age": 4, "form": "1-2-1-3"},
                {"number": 2, "name": "Midnight Star", "jockey": "A. Davis", "trainer": "M. Williams", "weight": "56.5kg", "age": 5, "form": "2-1-4-1"},
                {"number": 3, "name": "Golden Arrow", "jockey": "R. Wilson", "trainer": "S. Brown", "weight": "57kg", "age": 4, "form": "3-5-2-2"},
                {"number": 4, "name": "Silver Spirit", "jockey": "T. Miller", "trainer": "J. Davis", "weight": "55.5kg", "age": 6, "form": "4-3-1-5"},
                {"number": 5, "name": "Royal Flush", "jockey": "B. Taylor", "trainer": "R. Anderson", "weight": "56kg", "age": 5, "form": "6-4-3-1"},
                {"number": 6, "name": "Northern Light", "jockey": "M. Jones", "trainer": "D. White", "weight": "55kg", "age": 4, "form": "1-6-2-4"},
                {"number": 7, "name": "Lucky Charm", "jockey": "C. Brown", "trainer": "P. Martin", "weight": "54.5kg", "age": 3, "form": "3-1-5-3"},
                {"number": 8, "name": "Desert Wind", "jockey": "S. Walker", "trainer": "G. Thomas", "weight": "54kg", "age": 3, "form": "2-4-6-7"}
            ]
            
            # Display runners
            st.subheader("Runners")
            
            runners_df = pd.DataFrame(runners)
            st.dataframe(runners_df, hide_index=True)
            
            # Select horse for detailed analysis
            selected_horse = st.selectbox("Select horse for analysis", [r["name"] for r in runners])
            
            # Horse tabs
            tab1, tab2, tab3 = st.tabs(["Prediction", "Odds Comparison", "Horse Stats"])
            
            with tab1:
                # Prediction details
                with st.spinner("Generating prediction..."):
                    # Get the selected horse from the runners list
                    horse_details = next((r for r in runners if r["name"] == selected_horse), None)
                    
                    if horse_details:
                        # Create a match object expected by the prediction model
                        match = {
                            'horse_name': selected_horse,
                            'race_name': race.get('race_name', 'Race'),
                            'date': race.get('date', 'Date TBA'),
                            'venue': race.get('venue', 'Venue'),
                            'distance': race.get('distance', 'Distance')
                        }
                        
                        prediction = prediction_models.predict_match("Horse Racing", match)
                        
                        if prediction:
                            col1, col2 = st.columns(2)
                            with col1:
                                st.metric("Win Probability", f"{prediction['win_prob']:.1f}%")
                            with col2:
                                st.metric("Place Probability", f"{prediction['place_prob']:.1f}%")
                            
                            # Visualization of probabilities
                            fig_data = {
                                'Outcome': ['Win', 'Place'],
                                'Probability': [
                                    prediction['win_prob'],
                                    prediction['place_prob']
                                ]
                            }
                            df = pd.DataFrame(fig_data)
                            st.bar_chart(df, x='Outcome', y='Probability', use_container_width=True)
                            
                            st.subheader("Prediction Confidence")
                            st.progress(prediction['confidence'] / 100)
                            st.write(f"Confidence: {prediction['confidence']}%")
                            
                            st.markdown("### Key Factors")
                            for factor in prediction['key_factors']:
                                st.write(f"- {factor}")
                            
                            # Projected finish position
                            st.subheader("Projected Finish")
                            if prediction['win_prob'] > 30:
                                st.write("Projected to finish in the top 3 positions")
                            elif prediction['win_prob'] > 15:
                                st.write("Projected to finish in positions 4-6")
                            else:
                                st.write("Projected to finish outside the top 6")
                            
                            # Save prediction button
                            if st.button("Save Prediction"):
                                prediction_data = {
                                    'sport': "Horse Racing",
                                    'match': f"{selected_horse} - {race.get('race_name', 'Race')}",
                                    'date': race.get('date', 'Date TBA'),
                                    'prediction': prediction,
                                    'race_details': f"{race.get('venue', 'Venue')} - {race.get('distance', 'Distance')}"
                                }
                                utils.save_prediction(prediction_data)
                                st.success("Prediction saved successfully!")
                        else:
                            st.info("Insufficient data to generate prediction.")
            
            with tab2:
                # Odds comparison
                with st.spinner("Comparing odds across sportsbooks..."):
                    # Create a match object expected by the odds comparison module
                    match = {
                        'horse_name': selected_horse,
                        'race_name': race.get('race_name', 'Race'),
                        'date': race.get('date', 'Date TBA'),
                        'venue': race.get('venue', 'Venue'),
                        'distance': race.get('distance', 'Distance')
                    }
                    
                    odds_data = odds_comparison.get_odds_comparison("Horse Racing", match)
                    
                    if odds_data and len(odds_data) > 0:
                        st.subheader("Odds Comparison")
                        
                        # Odds format selection
                        odds_format = st.radio(
                            "Odds Format",
                            ["Decimal", "Fractional", "American"],
                            horizontal=True
                        )
                        
                        # Convert odds format based on selection
                        formatted_odds_data = []
                        for bookie_odds in odds_data:
                            formatted_odds = bookie_odds.copy()
                            
                            if odds_format == "Decimal":
                                # Already in decimal format
                                pass
                            elif odds_format == "Fractional":
                                formatted_odds['win_odds'] = utils.convert_odds_format(bookie_odds['win_odds'], "fractional")
                                formatted_odds['place_odds'] = utils.convert_odds_format(bookie_odds['place_odds'], "fractional")
                            elif odds_format == "American":
                                formatted_odds['win_odds'] = utils.convert_odds_format(bookie_odds['win_odds'], "american")
                                formatted_odds['place_odds'] = utils.convert_odds_format(bookie_odds['place_odds'], "american")
                            
                            formatted_odds_data.append(formatted_odds)
                        
                        # Convert to DataFrame for better display
                        odds_df = pd.DataFrame(formatted_odds_data)
                        st.dataframe(odds_df[['bookmaker', 'win_odds', 'place_odds']], hide_index=True)
                        
                        # Best odds highlighted
                        st.subheader("Best Available Odds")
                        best_odds = odds_comparison.get_best_odds(odds_data)
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric(
                                f"Win", 
                                utils.format_odds(best_odds['win']['odds']), 
                                f"at {best_odds['win']['bookmaker']}"
                            )
                        with col2:
                            st.metric(
                                f"Place", 
                                utils.format_odds(best_odds['place']['odds']), 
                                f"at {best_odds['place']['bookmaker']}"
                            )
                        
                        # Value bets section
                        if 'prediction' in locals():
                            st.subheader("Value Bet Analysis")
                            value_bets = odds_comparison.identify_value_bets(odds_data, prediction)
                            
                            if value_bets and len(value_bets) > 0:
                                for bet in value_bets:
                                    st.write(f"- {bet['description']} ({bet['value_percentage']:.1f}% edge)")
                                    
                                    # Calculate bankroll data
                                    bankroll_data = utils.get_bankroll_data()
                                    stake = utils.calculate_bet_amount(
                                        bankroll_data['current_bankroll'],
                                        bankroll_data['risk_percentage']
                                    )
                                    
                                    # Show potential return
                                    potential_return = stake * bet['odds']
                                    potential_profit = potential_return - stake
                                    
                                    st.caption(f"Recommended stake: ${stake:.2f} | Potential return: ${potential_return:.2f} | Potential profit: ${potential_profit:.2f}")
                                    
                                    # Place bet button (simulated)
                                    if st.button(f"Place bet", key=f"place_bet_{bet['bet_type']}"):
                                        st.success(f"Bet placed: ${stake:.2f} on {bet['bet_type']} at odds of {bet['odds']}")
                                        # In a real app, this would integrate with a betting platform
                            else:
                                st.write("No significant value bets identified for this horse.")
                    else:
                        st.info("No odds data available for this horse.")
            
            with tab3:
                # Horse stats
                with st.spinner("Loading horse statistics..."):
                    horse_stats = data_processor.get_team_stats("Horse Racing", selected_horse)
                    
                    if horse_stats:
                        st.subheader(f"{selected_horse} Statistics")
                        visualization.display_team_stats(horse_stats)
                        
                        # Additional horse-specific information
                        st.subheader("Horse Details")
                        
                        horse_details = next((r for r in runners if r["name"] == selected_horse), None)
                        if horse_details:
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Age", horse_details["age"])
                            with col2:
                                st.metric("Weight", horse_details["weight"])
                            with col3:
                                st.metric("Form", horse_details["form"])
                            
                            st.write(f"**Jockey:** {horse_details['jockey']}")
                            st.write(f"**Trainer:** {horse_details['trainer']}")
                        
                        # Track conditions and compatibility
                        st.subheader("Track Compatibility")
                        
                        # Simulated track condition data
                        track_condition = "Good to Firm"
                        track_type = "Turf"
                        track_direction = "Left-handed"
                        
                        st.write(f"**Current Track Condition:** {track_condition}")
                        st.write(f"**Track Type:** {track_type}")
                        st.write(f"**Track Direction:** {track_direction}")
                        
                        # Horse's performance on similar tracks
                        st.write(f"**Performance on {track_condition} conditions:** Good")
                        st.write(f"**Performance on {track_type} tracks:** Excellent")
                        st.write(f"**Performance at this distance:** Very Good")
                        
                        # Recent results
                        st.subheader("Recent Results")
                        
                        recent_results = [
                            {"date": "2023-04-15", "track": "Ascot", "position": 2, "distance": "1600m", "condition": "Good"},
                            {"date": "2023-03-02", "track": "Flemington", "position": 1, "distance": "1800m", "condition": "Good to Firm"},
                            {"date": "2023-02-01", "track": "Churchill Downs", "position": 4, "distance": "2000m", "condition": "Good"},
                            {"date": "2023-01-05", "track": "Meydan", "position": 1, "distance": "1600m", "condition": "Firm"}
                        ]
                        
                        results_df = pd.DataFrame(recent_results)
                        st.dataframe(results_df, hide_index=True)
                    else:
                        st.info("Horse statistics not available.")
    
    # Footer with additional information
    st.markdown("---")
    st.markdown("""
    ### About Horse Racing Predictions
    
    Our horse racing prediction model takes into account:
    - Horse's past performance and form
    - Jockey and trainer statistics
    - Track conditions and compatibility
    - Distance suitability
    - Weight carried
    - Recent training performance (when available)
    - Historical performance at the venue
    
    Horse racing is inherently more variable than many other sports, with many factors that can influence the outcome. For best results, use these predictions as one factor in your betting decisions, along with your own research and analysis.
    """)
