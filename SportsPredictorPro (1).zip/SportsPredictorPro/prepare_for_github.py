import os
import shutil
import subprocess

def prepare_for_github_pages():
    """
    Prepare the Streamlit app for GitHub Pages deployment.
    This creates a separate directory structure that can be pushed to GitHub.
    """
    # Create a docs directory (GitHub Pages can serve from /docs)
    if os.path.exists("docs"):
        shutil.rmtree("docs")
    os.makedirs("docs")
    
    # Create index.html that redirects to the Streamlit app
    index_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Prediction Platform</title>
    <link rel="manifest" href="static/manifest.json">
    <meta name="theme-color" content="#1E88E5">
    <link rel="apple-touch-icon" href="static/icon-192.png">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 40px 20px;
            color: #333;
            background-color: #f5f5f5;
        }
        .card {
            background-color: white;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #1E88E5;
        }
        .button {
            display: inline-block;
            background-color: #1E88E5;
            color: white;
            padding: 12px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            margin-top: 20px;
        }
        .logo {
            width: 120px;
            height: 120px;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <div class="card">
        <img src="static/icon-192.png" alt="App Logo" class="logo">
        <h1>Sports Prediction Platform</h1>
        <p>A multi-sport prediction platform for analyzing game outcomes and comparing odds across sportsbooks.</p>
        <p>This is a Progressive Web App that can be installed on your mobile device.</p>
        <a href="https://share.streamlit.io/Leratobriget/sports-prediction-platform/app.py" class="button">Launch App</a>
        <p>Or install this app on your device by clicking "Add to Home Screen" in your browser menu.</p>
    </div>

    <script>
        // Register service worker for PWA functionality
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/service-worker.js')
                    .then(reg => console.log('Service worker registered:', reg))
                    .catch(err => console.log('Service worker registration failed:', err));
            });
        }
    </script>
</body>
</html>
"""
    with open("docs/index.html", "w") as f:
        f.write(index_html)
    
    # Copy PWA assets
    os.makedirs("docs/static", exist_ok=True)
    
    # Copy icons and manifest
    shutil.copy(".streamlit/static/icon-192.png", "docs/static/")
    shutil.copy(".streamlit/static/icon-512.png", "docs/static/")
    shutil.copy(".streamlit/static/manifest.json", "docs/static/")
    
    # Copy service worker
    shutil.copy(".streamlit/static/service-worker.js", "docs/")
    
    # Create a README for the GitHub repo
    readme = """# Sports Prediction Platform

A multi-sport prediction platform for analyzing game outcomes, comparing odds across sportsbooks, and providing statistical insights with visual data presentation.

## Features

- Multi-sport coverage (Soccer, Basketball, Rugby, Cricket, Volleyball, Horse Racing)
- Game outcome predictions with probability analysis
- Odds comparison across multiple sportsbooks
- Value bet identification
- Historical match analysis
- Bankroll management tools
- Performance tracking

## Progressive Web App

This app has been configured as a Progressive Web App (PWA), which means you can install it on your mobile device without going through an app store:

1. Open the website in Chrome or another PWA-supporting browser
2. Tap the menu button (three dots)
3. Select "Add to Home Screen" or "Install App"
4. The app will be installed on your device like a native app

## Development

This app is built using Streamlit, a Python framework for data applications.

To run it locally:

1. Clone this repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the app: `streamlit run app.py`
"""
    with open("docs/README.md", "w") as f:
        f.write(readme)
    
    # Create a .nojekyll file to prevent GitHub Pages from using Jekyll
    with open("docs/.nojekyll", "w") as f:
        f.write("")
    
    print("GitHub Pages files prepared in the /docs directory!")
    print("Instructions:")
    print("1. Create a new GitHub repository")
    print("2. Push this code to the repository")
    print("3. In the repository settings, enable GitHub Pages from the /docs folder")
    print("4. The app URL has been pre-configured for your Streamlit app")
    print("5. Your PWA will be available at https://Leratobriget.github.io/sports-prediction-platform/")

if __name__ == "__main__":
    prepare_for_github_pages()