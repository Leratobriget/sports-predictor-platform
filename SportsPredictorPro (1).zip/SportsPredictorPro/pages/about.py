import streamlit as st
import pandas as pd
import utils
from datetime import datetime

def show():
    """
    Display the About page with information about the platform
    """
    st.title("About the Multi-Sport Prediction Platform")
    
    st.markdown("""
    ## Overview
    
    The Multi-Sport Prediction Platform provides data-driven predictions and statistical insights for a variety of sports. 
    Our platform combines advanced statistical models, historical data analysis, and real-time odds comparison to help you 
    make more informed betting decisions.
    
    ## Supported Sports
    """)
    
    # Sport cards
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"""
        ### {utils.get_sport_emoji('Soccer')} Soccer
        - Match outcomes (1X2)
        - Over/Under goals
        - Both teams to score
        - Handicap markets
        """)
        
        st.markdown(f"""
        ### {utils.get_sport_emoji('Cricket')} Cricket
        - Match winners
        - Over/Under runs
        - Top batsman/bowler
        - Innings scores
        """)
    
    with col2:
        st.markdown(f"""
        ### {utils.get_sport_emoji('Basketball')} Basketball
        - Match winners
        - Point spreads
        - Over/Under points
        - Team totals
        """)
        
        st.markdown(f"""
        ### {utils.get_sport_emoji('Volleyball')} Volleyball
        - Match winners
        - Set handicaps
        - Over/Under sets
        - Set scores
        """)
    
    with col3:
        st.markdown(f"""
        ### {utils.get_sport_emoji('Rugby')} Rugby
        - Match winners
        - Handicaps
        - Over/Under points
        - Try scorers
        """)
        
        st.markdown(f"""
        ### {utils.get_sport_emoji('Horse Racing')} Horse Racing
        - Win/Place markets
        - Exactas/Trifectas
        - Future markets
        - Race matchups
        """)
    
    st.markdown("""
    ## Key Features
    """)
    
    feature_data = [
        {"Feature": "Multi-sport coverage", "Description": "Predictions and analysis for six major sports"},
        {"Feature": "Game outcome predictions", "Description": "Probability-based predictions for match results"},
        {"Feature": "Odds comparison", "Description": "Compare odds across multiple sportsbooks to find the best value"},
        {"Feature": "Value bet identification", "Description": "Automatically identify bets with positive expected value"},
        {"Feature": "Historical analysis", "Description": "In-depth analysis of head-to-head matchups and team/player performance"},
        {"Feature": "Bankroll management", "Description": "Tools for optimal stake sizing and bankroll tracking"},
        {"Feature": "Performance tracking", "Description": "Monitor prediction accuracy and ROI over time"}
    ]
    
    features_df = pd.DataFrame(feature_data)
    st.dataframe(features_df, hide_index=True, use_container_width=True)
    
    st.markdown("""
    ## How It Works
    
    Our prediction platform uses a combination of statistical models, machine learning algorithms, and expert analysis to generate predictions. Here's how it works:
    """)
    
    st.markdown("""
    1. **Data Collection**: We gather comprehensive data on teams, players, matches, and odds from reliable sources.
    
    2. **Statistical Analysis**: Our models analyze historical performance, head-to-head records, recent form, and numerous other factors.
    
    3. **Probability Calculation**: Based on the analysis, we calculate the probability of each possible outcome.
    
    4. **Odds Comparison**: We compare our calculated probabilities with the odds offered by bookmakers to identify value.
    
    5. **Continuous Improvement**: Our models are continuously refined based on performance and new data.
    """)
    
    st.markdown("""
    ## Responsible Gambling
    
    We are committed to promoting responsible gambling practices. Please remember:
    
    - Sports betting should be viewed as entertainment, not a source of income
    - Only bet what you can afford to lose
    - Take regular breaks from betting
    - Never chase losses
    - Set deposit, wagering, and time limits
    
    If you or someone you know has a gambling problem, please reach out to a gambling support service.
    """)
    
    # FAQ section
    st.markdown("## Frequently Asked Questions")
    
    with st.expander("How accurate are the predictions?"):
        st.markdown("""
        Our prediction accuracy varies by sport and market type. Overall accuracy across all sports is approximately 75%, 
        but this can range from 65% to 80% depending on the specific sport and market. 
        
        It's important to understand that sports predictions are inherently probabilistic - even a 75% chance of winning means 
        there's a 25% chance of losing. For this reason, proper bankroll management is essential.
        
        You can view detailed accuracy metrics by sport in the Historical Performance section.
        """)
    
    with st.expander("How is the Confidence percentage calculated?"):
        st.markdown("""
        The Confidence percentage represents how certain our model is about its prediction. It's calculated based on:
        
        - The quality and quantity of data available
        - The consistency of patterns in the data
        - The stability of our probability estimates
        - The historical accuracy of similar predictions
        
        A higher confidence percentage generally indicates a more reliable prediction, but it's important to remember 
        that even high-confidence predictions can be wrong due to the inherent unpredictability of sports.
        """)
    
    with st.expander("What data sources do you use?"):
        st.markdown("""
        We use a combination of data sources including:
        
        - Official league and competition statistics
        - Historical match results and performance data
        - Team and player metrics from specialized sports analytics providers
        - Real-time odds from multiple bookmakers
        
        All data is regularly validated and updated to ensure accuracy. Due to data licensing agreements, 
        we cannot disclose the specific data providers.
        """)
    
    with st.expander("How often are predictions updated?"):
        st.markdown("""
        Predictions are initially generated when matches are announced and fixtures are set. They are then updated:
        
        - When new team information becomes available (injuries, lineup changes, etc.)
        - When there are significant odds movements
        - 24 hours before the event
        - A few hours before the event with final team news
        
        For in-play predictions (where available), updates occur continuously during the event.
        """)
    
    with st.expander("Can I export predictions and data?"):
        st.markdown("""
        Yes, we're planning to add export functionality in a future update that will allow you to download:
        
        - Your saved predictions
        - Historical performance data
        - Bankroll management records
        - Odds comparison tables
        
        The exports will be available in CSV and Excel formats.
        """)
    
    # Version and update info
    st.markdown("---")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Platform Version:** 1.0.0 Beta")
        st.markdown(f"**Last Updated:** {datetime.now().strftime('%B %d, %Y')}")
        
    with col2:
        st.markdown("**Contact:** support@sportspredictionplatform.com")
        st.markdown("**Feedback:** We welcome your suggestions and feedback!")
    
    # Disclaimer
    st.markdown("---")
    st.caption("""
    **Disclaimer:** This platform is designed for informational and entertainment purposes only. 
    While we strive to provide accurate predictions, we cannot guarantee success in sports betting. 
    Past performance is not indicative of future results. Always gamble responsibly and be aware of the risks involved.
    """)
