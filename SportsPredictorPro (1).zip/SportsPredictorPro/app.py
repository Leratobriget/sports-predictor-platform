import streamlit as st
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta

# Import custom modules
import data_processor
import prediction_models
import odds_comparison
import visualization
import utils

# Page configuration
st.set_page_config(
    page_title="Sports Prediction Platform",
    page_icon="🏆",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Session state initialization
if 'selected_sport' not in st.session_state:
    st.session_state.selected_sport = "Soccer"
if 'api_error' not in st.session_state:
    st.session_state.api_error = None

# Title and introduction
st.title("Multi-Sport Prediction Platform")
st.markdown("""
This platform provides data-driven predictions for various sports events, 
compares odds across sportsbooks, and offers statistical insights to help you make informed decisions.
""")

# Sidebar with navigation
st.sidebar.title("Navigation")
selected_page = st.sidebar.radio(
    "Go to",
    ["Home", "Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing", 
     "Bankroll Management", "Notifications", "Historical Performance", "About"]
)

# Display selected sport data in the main page if "Home" is selected
if selected_page == "Home":
    # API key warning if not set
    utils.check_api_keys()
    
    if st.session_state.api_error:
        st.error(st.session_state.api_error)
    
    # Sport selection
    sport_options = ["Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"]
    selected_sport = st.selectbox("Select a sport", sport_options)
    st.session_state.selected_sport = selected_sport
    
    # Date selection
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    date_options = [today, tomorrow, today + timedelta(days=2), today + timedelta(days=3), 
                   today + timedelta(days=4), today + timedelta(days=5), today + timedelta(days=6)]
    selected_date = st.date_input("Select date", today, min_value=today, max_value=today + timedelta(days=30))
    
    # Get upcoming matches
    with st.spinner(f"Loading upcoming {selected_sport} matches..."):
        try:
            upcoming_matches = data_processor.get_upcoming_matches(selected_sport, selected_date)
            
            if upcoming_matches is None or len(upcoming_matches) == 0:
                st.info(f"No upcoming {selected_sport} matches found for the selected date.")
            else:
                st.subheader(f"Upcoming {selected_sport} Matches - {selected_date}")
                # Display matches
                for idx, match in enumerate(upcoming_matches):
                    col1, col2, col3 = st.columns([2, 1, 2])
                    with col1:
                        st.write(f"**{match['home_team']}**")
                    with col2:
                        st.write("vs")
                    with col3:
                        st.write(f"**{match['away_team']}**")
                    
                    if st.button(f"Analyze Match #{idx+1}", key=f"analyze_{idx}"):
                        st.session_state.selected_match = match
                        st.session_state.match_analysis = True
                    
                    st.markdown("---")
                
                # If a match is selected for analysis
                if 'match_analysis' in st.session_state and st.session_state.match_analysis:
                    match = st.session_state.selected_match
                    st.subheader(f"Match Analysis: {match['home_team']} vs {match['away_team']}")
                    
                    # Match tabs
                    tab1, tab2, tab3, tab4 = st.tabs(["Prediction", "Odds Comparison", "Team Stats", "Historical Matchups"])
                    
                    with tab1:
                        # Prediction details
                        with st.spinner("Generating prediction..."):
                            prediction = prediction_models.predict_match(selected_sport, match)
                            
                            if prediction:
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Home Win Probability", f"{prediction['home_win_prob']:.1f}%")
                                with col2:
                                    if "draw_prob" in prediction:
                                        st.metric("Draw Probability", f"{prediction['draw_prob']:.1f}%")
                                with col3:
                                    st.metric("Away Win Probability", f"{prediction['away_win_prob']:.1f}%")
                                
                                st.subheader("Prediction Confidence")
                                st.progress(prediction['confidence'] / 100)
                                st.write(f"Confidence: {prediction['confidence']}%")
                                
                                st.markdown("### Key Factors")
                                for factor in prediction['key_factors']:
                                    st.write(f"- {factor}")
                            else:
                                st.info("Insufficient data to generate prediction.")
                    
                    with tab2:
                        # Odds comparison
                        with st.spinner("Comparing odds across sportsbooks..."):
                            odds_data = odds_comparison.get_odds_comparison(selected_sport, match)
                            
                            if odds_data and len(odds_data) > 0:
                                st.subheader("Odds Comparison")
                                
                                # Convert to DataFrame for better display
                                odds_df = pd.DataFrame(odds_data)
                                st.dataframe(odds_df)
                                
                                # Best odds highlighted
                                st.subheader("Best Available Odds")
                                best_odds = odds_comparison.get_best_odds(odds_data)
                                
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric(f"{match['home_team']} Win", 
                                             f"{best_odds['home_win']['odds']}", 
                                             f"at {best_odds['home_win']['bookmaker']}")
                                with col2:
                                    if 'draw' in best_odds:
                                        st.metric(f"Draw", 
                                                 f"{best_odds['draw']['odds']}", 
                                                 f"at {best_odds['draw']['bookmaker']}")
                                with col3:
                                    st.metric(f"{match['away_team']} Win", 
                                             f"{best_odds['away_win']['odds']}", 
                                             f"at {best_odds['away_win']['bookmaker']}")
                                
                                # Value bets
                                st.subheader("Value Bet Analysis")
                                value_bets = odds_comparison.identify_value_bets(odds_data, prediction)
                                
                                if value_bets and len(value_bets) > 0:
                                    for bet in value_bets:
                                        st.write(f"- {bet['description']} ({bet['value_percentage']:.1f}% edge)")
                                else:
                                    st.write("No significant value bets identified for this match.")
                            else:
                                st.info("No odds data available for this match.")
                    
                    with tab3:
                        # Team stats
                        with st.spinner("Loading team statistics..."):
                            home_stats = data_processor.get_team_stats(selected_sport, match['home_team'])
                            away_stats = data_processor.get_team_stats(selected_sport, match['away_team'])
                            
                            if home_stats and away_stats:
                                col1, col2 = st.columns(2)
                                
                                with col1:
                                    st.subheader(f"{match['home_team']} Stats")
                                    visualization.display_team_stats(home_stats)
                                
                                with col2:
                                    st.subheader(f"{match['away_team']} Stats")
                                    visualization.display_team_stats(away_stats)
                                
                                # Head-to-head comparison
                                st.subheader("Head-to-Head Comparison")
                                visualization.compare_team_stats(home_stats, away_stats, match)
                            else:
                                st.info("Team statistics not available.")
                    
                    with tab4:
                        # Historical matchups
                        with st.spinner("Loading historical matchups..."):
                            historical_matches = data_processor.get_historical_matchups(
                                selected_sport, match['home_team'], match['away_team']
                            )
                            
                            if historical_matches and len(historical_matches) > 0:
                                st.subheader(f"Previous {match['home_team']} vs {match['away_team']} Matches")
                                
                                # Display historical results
                                for hist_match in historical_matches:
                                    st.write(f"{hist_match['date']} - {hist_match['home_team']} {hist_match['home_score']} vs " +
                                             f"{hist_match['away_score']} {hist_match['away_team']}")
                                
                                # Visualization of historical matchups
                                visualization.plot_historical_matchups(historical_matches)
                            else:
                                st.info("No historical matchups found between these teams.")
        except Exception as e:
            st.error(f"Error loading match data: {str(e)}")
            st.session_state.api_error = f"API Error: {str(e)}"
            
    # Summary metrics
    st.subheader("Platform Summary")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Prediction Accuracy", "74.8%", "+2.3%")
    with col2:
        st.metric("Sports Covered", "6", "")
    with col3:
        st.metric("Sportsbooks Compared", "12", "")
    with col4:
        st.metric("ROI (Last 30 Days)", "+5.7%", "+0.8%")

# Navigate to the respective page based on selection
elif selected_page != "Home":
    # Import and run the selected page
    try:
        if selected_page == "Soccer":
            import pages.soccer
            pages.soccer.show()
        elif selected_page == "Basketball":
            import pages.basketball
            pages.basketball.show()
        elif selected_page == "Rugby":
            import pages.rugby
            pages.rugby.show()
        elif selected_page == "Cricket":
            import pages.cricket
            pages.cricket.show()
        elif selected_page == "Volleyball":
            import pages.volleyball
            pages.volleyball.show()
        elif selected_page == "Horse Racing":
            import pages.horse_racing
            pages.horse_racing.show()
        elif selected_page == "Bankroll Management":
            import pages.bankroll_management
            pages.bankroll_management.show()
        elif selected_page == "Notifications":
            import pages.notifications
            pages.notifications.show()
        elif selected_page == "Historical Performance":
            import pages.historical_performance
            pages.historical_performance.show()
        elif selected_page == "About":
            import pages.about
            pages.about.show()
    except Exception as e:
        st.error(f"Error loading page: {str(e)}")

# Footer
st.markdown("---")
st.markdown("© 2023 Multi-Sport Prediction Platform | Data-driven sports predictions")
