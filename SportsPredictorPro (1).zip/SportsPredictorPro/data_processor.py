import pandas as pd
import numpy as np
import requests
import json
from datetime import datetime, timedelta
import os
import time
import streamlit as st

# API configurations and endpoints
# We'll use a combination of free and paid sports data APIs
# For the MVP, we'll focus on these primary APIs:
# - Sports Data IO
# - The Odds API
# - Football-Data.org

# API keys from environment variables
SPORTS_DATA_API_KEY = os.getenv("SPORTS_DATA_API_KEY", "")
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "")
FOOTBALL_DATA_API_KEY = os.getenv("FOOTBALL_DATA_API_KEY", "")
CRICKET_API_KEY = os.getenv("CRICKET_API_KEY", "")

# Cache TTL in seconds (5 minutes)
CACHE_TTL = 300

# Dictionary with API endpoints for different sports
API_ENDPOINTS = {
    "Soccer": {
        "upcoming": "https://api.football-data.org/v2/matches",
        "team_stats": "https://api.football-data.org/v2/teams/{team_id}/matches",
        "historical": "https://api.football-data.org/v2/teams/{team_id}/matches?status=FINISHED"
    },
    "Basketball": {
        "upcoming": "https://api.sportsdata.io/v3/nba/scores/json/Games/{season}",
        "team_stats": "https://api.sportsdata.io/v3/nba/stats/json/TeamSeasonStats/{season}",
        "historical": "https://api.sportsdata.io/v3/nba/scores/json/TeamGameStatsBySeason/{season}/{team_id}"
    },
    "Rugby": {
        "upcoming": "https://api.sportsdata.io/v3/rugby/scores/json/Competitions",
        "team_stats": "https://api.sportsdata.io/v3/rugby/scores/json/Teams/{competition_id}",
        "historical": "https://api.sportsdata.io/v3/rugby/scores/json/Games/{season}"
    },
    "Cricket": {
        "upcoming": "https://cricket.sportmonks.com/api/v2.0/fixtures?api_token={api_key}",
        "team_stats": "https://cricket.sportmonks.com/api/v2.0/teams/{team_id}?api_token={api_key}",
        "historical": "https://cricket.sportmonks.com/api/v2.0/fixtures/between/{from}/{to}?api_token={api_key}"
    },
    "Volleyball": {
        "upcoming": "https://api.sportsdata.io/v3/volleyball/scores/json/Competitions",
        "team_stats": "https://api.sportsdata.io/v3/volleyball/scores/json/Teams/{competition_id}",
        "historical": "https://api.sportsdata.io/v3/volleyball/scores/json/Games/{season}"
    },
    "Horse Racing": {
        "upcoming": "https://api.sportsdata.io/v3/horseracing/scores/json/Races/{date}",
        "team_stats": "https://api.sportsdata.io/v3/horseracing/scores/json/Horses",
        "historical": "https://api.sportsdata.io/v3/horseracing/scores/json/RaceResults/{race_id}"
    }
}

# Cache for API responses
api_cache = {}

def get_api_data(url, headers=None, params=None):
    """
    Generic function to get data from APIs with caching
    """
    cache_key = f"{url}_{json.dumps(params) if params else ''}"
    
    # Check if we have a valid cached response
    if cache_key in api_cache:
        cache_time, cache_data = api_cache[cache_key]
        if time.time() - cache_time < CACHE_TTL:
            return cache_data
    
    # If no cache or expired, make a new request
    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()  # Raise exception for non-200 responses
        data = response.json()
        
        # Cache the response
        api_cache[cache_key] = (time.time(), data)
        
        return data
    except requests.exceptions.RequestException as e:
        st.error(f"API request failed: {str(e)}")
        return None

def get_upcoming_matches(sport, date):
    """
    Get upcoming matches for a specific sport and date
    """
    if sport not in API_ENDPOINTS:
        return []
    
    # Format date as required by APIs
    date_str = date.strftime("%Y-%m-%d")
    
    # Different handling based on sport
    if sport == "Soccer":
        headers = {"X-Auth-Token": FOOTBALL_DATA_API_KEY}
        params = {"dateFrom": date_str, "dateTo": date_str}
        url = API_ENDPOINTS[sport]["upcoming"]
        
        # If we're using mock data for development
        if not FOOTBALL_DATA_API_KEY:
            # Return mock data for development
            return [
                {"id": 1, "home_team": "Manchester United", "away_team": "Liverpool", "date": date_str, "time": "15:00"},
                {"id": 2, "home_team": "Arsenal", "away_team": "Chelsea", "date": date_str, "time": "17:30"},
                {"id": 3, "home_team": "Manchester City", "away_team": "Tottenham", "date": date_str, "time": "20:00"}
            ]
        
        data = get_api_data(url, headers=headers, params=params)
        
        if data and "matches" in data:
            return [
                {
                    "id": match["id"],
                    "home_team": match["homeTeam"]["name"],
                    "away_team": match["awayTeam"]["name"],
                    "date": match["utcDate"].split("T")[0],
                    "time": match["utcDate"].split("T")[1][:5],
                    "competition": match["competition"]["name"]
                }
                for match in data["matches"]
            ]
    
    elif sport == "Basketball":
        headers = {"Ocp-Apim-Subscription-Key": SPORTS_DATA_API_KEY}
        # For NBA, we need to determine the season
        current_year = datetime.now().year
        month = datetime.now().month
        season = f"{current_year}-{current_year+1}" if month >= 10 else f"{current_year-1}-{current_year}"
        
        url = API_ENDPOINTS[sport]["upcoming"].replace("{season}", season)
        
        # If we're using mock data for development
        if not SPORTS_DATA_API_KEY:
            return [
                {"id": 1, "home_team": "LA Lakers", "away_team": "Chicago Bulls", "date": date_str, "time": "19:30"},
                {"id": 2, "home_team": "Boston Celtics", "away_team": "Brooklyn Nets", "date": date_str, "time": "20:00"},
                {"id": 3, "home_team": "Miami Heat", "away_team": "Philadelphia 76ers", "date": date_str, "time": "18:00"}
            ]
        
        data = get_api_data(url, headers=headers)
        
        if data:
            # Filter games for the selected date
            filtered_games = [game for game in data if game["Day"].split("T")[0] == date_str]
            
            return [
                {
                    "id": game["GameID"],
                    "home_team": game["HomeTeam"],
                    "away_team": game["AwayTeam"],
                    "date": game["Day"].split("T")[0],
                    "time": game["DateTime"].split("T")[1][:5],
                    "stadium": game["Stadium"]
                }
                for game in filtered_games
            ]
    
    elif sport == "Rugby":
        # Similar implementation for Rugby
        # For MVP, provide some sample data
        return [
            {"id": 1, "home_team": "New Zealand", "away_team": "South Africa", "date": date_str, "time": "14:00"},
            {"id": 2, "home_team": "England", "away_team": "Wales", "date": date_str, "time": "16:30"},
            {"id": 3, "home_team": "Ireland", "away_team": "Scotland", "date": date_str, "time": "19:00"}
        ]
    
    elif sport == "Cricket":
        # Cricket API implementation
        # For MVP, provide some sample data
        return [
            {"id": 1, "home_team": "India", "away_team": "Australia", "date": date_str, "time": "10:00", "format": "Test"},
            {"id": 2, "home_team": "England", "away_team": "Pakistan", "date": date_str, "time": "13:30", "format": "ODI"},
            {"id": 3, "home_team": "West Indies", "away_team": "South Africa", "date": date_str, "time": "18:00", "format": "T20"}
        ]
    
    elif sport == "Volleyball":
        # Volleyball implementation
        # For MVP, provide some sample data
        return [
            {"id": 1, "home_team": "Brazil", "away_team": "Italy", "date": date_str, "time": "16:00"},
            {"id": 2, "home_team": "Russia", "away_team": "USA", "date": date_str, "time": "18:30"},
            {"id": 3, "home_team": "Poland", "away_team": "France", "date": date_str, "time": "20:00"}
        ]
    
    elif sport == "Horse Racing":
        # Horse Racing implementation
        # For MVP, provide some sample data
        return [
            {"id": 1, "race_name": "Melbourne Cup", "venue": "Flemington", "date": date_str, "time": "15:00", "distance": "3200m"},
            {"id": 2, "race_name": "Kentucky Derby", "venue": "Churchill Downs", "date": date_str, "time": "18:30", "distance": "2000m"},
            {"id": 3, "race_name": "Royal Ascot", "venue": "Ascot", "date": date_str, "time": "14:00", "distance": "2400m"}
        ]
    
    # Default empty list if no matches found or API error
    return []

def get_team_stats(sport, team_name):
    """
    Get team statistics for analysis
    """
    # In a real implementation, this would call the respective API to get team stats
    # For MVP, returning sample data
    
    if sport == "Soccer":
        return {
            "team_name": team_name,
            "matches_played": 38,
            "wins": 22,
            "draws": 8,
            "losses": 8,
            "goals_scored": 74,
            "goals_conceded": 36,
            "clean_sheets": 12,
            "form": ["W", "W", "D", "L", "W"],
            "home_form": ["W", "W", "W", "D", "W"],
            "away_form": ["L", "D", "W", "L", "D"],
            "xG": 68.5,
            "xGA": 40.2,
            "ppg": 1.95
        }
    elif sport == "Basketball":
        return {
            "team_name": team_name,
            "games_played": 82,
            "wins": 48,
            "losses": 34,
            "pts_per_game": 110.5,
            "pts_allowed": 105.2,
            "fg_percentage": 46.8,
            "three_pt_percentage": 36.5,
            "rebounds_per_game": 43.2,
            "assists_per_game": 24.6,
            "home_record": "26-15",
            "away_record": "22-19",
            "form": ["W", "W", "L", "W", "L"]
        }
    elif sport == "Rugby":
        return {
            "team_name": team_name,
            "matches_played": 14,
            "wins": 9,
            "draws": 1,
            "losses": 4,
            "points_scored": 312,
            "points_conceded": 240,
            "tries_scored": 35,
            "penalties_conceded": 48,
            "home_record": "6-1-0",
            "away_record": "3-0-4",
            "form": ["W", "W", "L", "W", "D"]
        }
    elif sport == "Cricket":
        return {
            "team_name": team_name,
            "matches_played": 20,
            "wins": 12,
            "draws": 2,
            "losses": 6,
            "batting_avg": 287,
            "bowling_avg": 245,
            "run_rate": 5.6,
            "wickets_taken": 152,
            "home_record": "8-1-1",
            "away_record": "4-1-5",
            "form": ["W", "W", "L", "D", "W"]
        }
    elif sport == "Volleyball":
        return {
            "team_name": team_name,
            "matches_played": 25,
            "wins": 16,
            "losses": 9,
            "sets_won": 54,
            "sets_lost": 38,
            "points_scored": 1245,
            "points_conceded": 1150,
            "service_aces": 87,
            "blocks": 134,
            "home_record": "10-3",
            "away_record": "6-6",
            "form": ["W", "L", "W", "W", "L"]
        }
    elif sport == "Horse Racing":
        # For horse racing, return stats about a horse
        return {
            "horse_name": team_name,
            "races": 15,
            "wins": 6,
            "places": 3,
            "shows": 2,
            "win_percentage": 40.0,
            "in_the_money_percentage": 73.3,
            "avg_speed_rating": 92.5,
            "best_distance": "1600m",
            "track_preference": "Firm",
            "last_5_finishes": [1, 3, 1, 2, 4],
            "jockey": "John Smith",
            "trainer": "Bob Johnson"
        }
    
    # Default return empty dict if sport not supported
    return {}

def get_historical_matchups(sport, team1, team2):
    """
    Get historical matchups between two teams
    """
    # In a real implementation, this would call the respective API
    # For MVP, returning sample data
    
    if sport == "Soccer":
        return [
            {"date": "2023-02-15", "home_team": team1, "away_team": team2, "home_score": 2, "away_score": 1},
            {"date": "2022-10-08", "home_team": team2, "away_team": team1, "home_score": 0, "away_score": 0},
            {"date": "2022-03-20", "home_team": team1, "away_team": team2, "home_score": 1, "away_score": 3},
            {"date": "2021-11-05", "home_team": team2, "away_team": team1, "home_score": 2, "away_score": 2},
            {"date": "2021-04-18", "home_team": team1, "away_team": team2, "home_score": 3, "away_score": 1}
        ]
    elif sport == "Basketball":
        return [
            {"date": "2023-01-25", "home_team": team1, "away_team": team2, "home_score": 105, "away_score": 98},
            {"date": "2022-11-12", "home_team": team2, "away_team": team1, "home_score": 112, "away_score": 108},
            {"date": "2022-04-04", "home_team": team1, "away_team": team2, "home_score": 95, "away_score": 103},
            {"date": "2022-01-15", "home_team": team2, "away_team": team1, "home_score": 92, "away_score": 89},
            {"date": "2021-10-30", "home_team": team1, "away_team": team2, "home_score": 110, "away_score": 102}
        ]
    elif sport == "Rugby":
        return [
            {"date": "2023-03-18", "home_team": team1, "away_team": team2, "home_score": 24, "away_score": 18},
            {"date": "2022-09-24", "home_team": team2, "away_team": team1, "home_score": 30, "away_score": 22},
            {"date": "2022-02-05", "home_team": team1, "away_team": team2, "home_score": 15, "away_score": 15},
            {"date": "2021-10-16", "home_team": team2, "away_team": team1, "home_score": 12, "away_score": 24},
            {"date": "2021-05-08", "home_team": team1, "away_team": team2, "home_score": 28, "away_score": 20}
        ]
    elif sport == "Cricket":
        return [
            {"date": "2023-01-08", "home_team": team1, "away_team": team2, "home_score": "285/7", "away_score": "240/10"},
            {"date": "2022-08-12", "home_team": team2, "away_team": team1, "home_score": "320/8", "away_score": "305/9"},
            {"date": "2022-02-20", "home_team": team1, "away_team": team2, "home_score": "210/10", "away_score": "215/6"},
            {"date": "2021-11-30", "home_team": team2, "away_team": team1, "home_score": "195/10", "away_score": "198/4"},
            {"date": "2021-06-15", "home_team": team1, "away_team": team2, "home_score": "275/8", "away_score": "220/10"}
        ]
    elif sport == "Volleyball":
        return [
            {"date": "2023-02-25", "home_team": team1, "away_team": team2, "home_score": 3, "away_score": 1},
            {"date": "2022-10-12", "home_team": team2, "away_team": team1, "home_score": 3, "away_score": 2},
            {"date": "2022-03-08", "home_team": team1, "away_team": team2, "home_score": 0, "away_score": 3},
            {"date": "2021-11-20", "home_team": team2, "away_team": team1, "home_score": 1, "away_score": 3},
            {"date": "2021-05-15", "home_team": team1, "away_team": team2, "home_score": 3, "away_score": 0}
        ]
    elif sport == "Horse Racing":
        # For horse racing, this doesn't really apply in the same way
        # Return empty list for now
        return []
    
    # Default empty list
    return []

def get_home_away_advantage(sport):
    """
    Get home/away advantage statistics for a sport
    """
    if sport == "Soccer":
        return {
            "home_win_percentage": 48.2,
            "away_win_percentage": 28.7,
            "draw_percentage": 23.1,
            "home_goals_per_game": 1.55,
            "away_goals_per_game": 1.12
        }
    elif sport == "Basketball":
        return {
            "home_win_percentage": 58.6,
            "away_win_percentage": 41.4,
            "home_points_per_game": 110.2,
            "away_points_per_game": 106.8
        }
    elif sport == "Rugby":
        return {
            "home_win_percentage": 60.3,
            "away_win_percentage": 36.5,
            "draw_percentage": 3.2,
            "home_points_per_game": 26.8,
            "away_points_per_game": 21.3
        }
    elif sport == "Cricket":
        return {
            "home_win_percentage": 54.7,
            "away_win_percentage": 38.2,
            "draw_percentage": 7.1,
            "home_runs_per_game": 295,
            "away_runs_per_game": 265
        }
    elif sport == "Volleyball":
        return {
            "home_win_percentage": 62.8,
            "away_win_percentage": 37.2,
            "home_sets_won_percentage": 58.4,
            "away_sets_won_percentage": 41.6
        }
    # For horse racing, home/away advantage doesn't apply in the same way
    
    # Default
    return {}

def get_prediction_performance():
    """
    Get historical prediction performance metrics
    """
    # In a real app, this would come from a database of past predictions
    # For MVP, returning sample data
    
    return {
        "overall_accuracy": 74.8,
        "sport_accuracy": {
            "Soccer": 76.5,
            "Basketball": 73.2,
            "Rugby": 70.8,
            "Cricket": 68.9,
            "Volleyball": 72.4,
            "Horse Racing": 65.3
        },
        "monthly_accuracy": [72.6, 73.1, 73.8, 74.5, 75.2, 74.8],
        "roi": 5.7,
        "predictions_count": 1245
    }
