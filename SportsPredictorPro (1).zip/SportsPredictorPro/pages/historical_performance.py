import streamlit as st
import pandas as pd
import numpy as np
import data_processor
import visualization
import utils
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def show():
    """
    Display the Historical Performance page
    """
    st.title("Historical Performance 📊")
    
    # Get prediction history
    prediction_history = utils.get_prediction_history()
    
    # Simulated historical performance metrics
    performance_data = data_processor.get_prediction_performance()
    
    # Overall performance metrics
    st.header("Overall Prediction Performance")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Overall Accuracy", 
            f"{performance_data['overall_accuracy']}%", 
            "+2.3%"
        )
    with col2:
        st.metric(
            "Predictions Made", 
            performance_data['predictions_count']
        )
    with col3:
        st.metric(
            "ROI", 
            f"{performance_data['roi']}%", 
            "+0.8%"
        )
    with col4:
        most_accurate_sport = max(performance_data['sport_accuracy'].items(), key=lambda x: x[1])
        st.metric(
            "Best Sport", 
            f"{most_accurate_sport[0]}",
            f"{most_accurate_sport[1]}% accuracy"
        )
    
    # Performance over time
    st.markdown("---")
    st.header("Performance Trends")
    
    # Accuracy trend chart
    st.subheader("Prediction Accuracy Over Time")
    accuracy_trend_fig = visualization.plot_prediction_accuracy(performance_data)
    st.plotly_chart(accuracy_trend_fig, use_container_width=True)
    
    # Sport-specific accuracy
    st.subheader("Accuracy by Sport")
    sport_accuracy_fig = visualization.plot_sport_accuracy(performance_data)
    st.plotly_chart(sport_accuracy_fig, use_container_width=True)
    
    # Performance by Sport
    st.markdown("---")
    st.header("Detailed Sport Analysis")
    
    sport_tabs = st.tabs(["Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"])
    
    for i, sport in enumerate(["Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"]):
        with sport_tabs[i]:
            st.subheader(f"{sport} Prediction Analysis")
            
            # Sport-specific accuracy
            st.metric(
                "Prediction Accuracy", 
                f"{performance_data['sport_accuracy'][sport]}%"
            )
            
            # Simulated sport-specific data
            if sport == "Soccer":
                # Market accuracy for soccer
                market_data = {
                    "Market": ["1X2", "Over/Under", "Both Teams to Score", "Correct Score", "Asian Handicap"],
                    "Accuracy": [78.2, 72.5, 68.9, 22.1, 71.8]
                }
                market_df = pd.DataFrame(market_data)
                
                fig = px.bar(
                    market_df,
                    x="Market",
                    y="Accuracy",
                    text_auto='.1f',
                    title="Accuracy by Market Type",
                    labels={"Accuracy": "Accuracy (%)"}
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
                
                # League-specific performance
                st.subheader("Performance by League")
                league_data = {
                    "League": ["Premier League", "La Liga", "Bundesliga", "Serie A", "Ligue 1"],
                    "Accuracy": [79.5, 77.8, 75.2, 72.1, 73.9],
                    "ROI": [7.2, 6.5, 4.9, 5.1, 4.2]
                }
                league_df = pd.DataFrame(league_data)
                
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                
                fig.add_trace(
                    go.Bar(
                        x=league_df["League"],
                        y=league_df["Accuracy"],
                        name="Accuracy (%)",
                        marker_color="#1E88E5"
                    ),
                    secondary_y=False
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=league_df["League"],
                        y=league_df["ROI"],
                        name="ROI (%)",
                        marker_color="#FF5722",
                        mode="lines+markers"
                    ),
                    secondary_y=True
                )
                
                fig.update_layout(
                    title="Performance by League",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5)
                )
                
                fig.update_yaxes(title_text="Accuracy (%)", secondary_y=False)
                fig.update_yaxes(title_text="ROI (%)", secondary_y=True)
                
                st.plotly_chart(fig, use_container_width=True)
                
            elif sport == "Basketball":
                # Market accuracy for basketball
                market_data = {
                    "Market": ["Moneyline", "Spread", "Total Points", "Team Points", "Player Props"],
                    "Accuracy": [73.5, 71.9, 68.2, 65.4, 61.7]
                }
                market_df = pd.DataFrame(market_data)
                
                fig = px.bar(
                    market_df,
                    x="Market",
                    y="Accuracy",
                    text_auto='.1f',
                    title="Accuracy by Market Type",
                    labels={"Accuracy": "Accuracy (%)"}
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
                
                # League-specific performance
                st.subheader("Performance by League")
                league_data = {
                    "League": ["NBA", "EuroLeague", "NCAA", "FIBA World Cup"],
                    "Accuracy": [74.2, 72.5, 68.9, 71.8],
                    "ROI": [5.8, 6.2, 4.5, 7.1]
                }
                league_df = pd.DataFrame(league_data)
                
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                
                fig.add_trace(
                    go.Bar(
                        x=league_df["League"],
                        y=league_df["Accuracy"],
                        name="Accuracy (%)",
                        marker_color="#1E88E5"
                    ),
                    secondary_y=False
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=league_df["League"],
                        y=league_df["ROI"],
                        name="ROI (%)",
                        marker_color="#FF5722",
                        mode="lines+markers"
                    ),
                    secondary_y=True
                )
                
                fig.update_layout(
                    title="Performance by League",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5)
                )
                
                fig.update_yaxes(title_text="Accuracy (%)", secondary_y=False)
                fig.update_yaxes(title_text="ROI (%)", secondary_y=True)
                
                st.plotly_chart(fig, use_container_width=True)
                
            elif sport == "Horse Racing":
                # Additional horse racing specific metrics
                st.subheader("Performance by Bet Type")
                
                bet_type_data = {
                    "Bet Type": ["Win", "Place", "Show", "Exacta", "Trifecta"],
                    "Accuracy": [22.5, 41.8, 65.2, 12.4, 8.9],
                    "ROI": [15.2, 8.5, 4.9, 32.5, 45.8]
                }
                bet_type_df = pd.DataFrame(bet_type_data)
                
                fig = make_subplots(specs=[[{"secondary_y": True}]])
                
                fig.add_trace(
                    go.Bar(
                        x=bet_type_df["Bet Type"],
                        y=bet_type_df["Accuracy"],
                        name="Accuracy (%)",
                        marker_color="#1E88E5"
                    ),
                    secondary_y=False
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=bet_type_df["Bet Type"],
                        y=bet_type_df["ROI"],
                        name="ROI (%)",
                        marker_color="#FF5722",
                        mode="lines+markers"
                    ),
                    secondary_y=True
                )
                
                fig.update_layout(
                    title="Performance by Bet Type",
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5)
                )
                
                fig.update_yaxes(title_text="Accuracy (%)", secondary_y=False)
                fig.update_yaxes(title_text="ROI (%)", secondary_y=True)
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Performance by track condition
                st.subheader("Performance by Track Condition")
                track_condition_data = {
                    "Condition": ["Firm", "Good", "Soft", "Heavy", "Synthetic"],
                    "Accuracy": [68.5, 70.2, 65.8, 59.2, 67.1],
                    "ROI": [8.5, 7.2, 9.8, 11.5, 7.9]
                }
                track_df = pd.DataFrame(track_condition_data)
                
                fig = px.bar(
                    track_df,
                    x="Condition",
                    y="Accuracy",
                    text_auto='.1f',
                    title="Accuracy by Track Condition",
                    labels={"Accuracy": "Accuracy (%)"}
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
                
            else:
                # Generic performance metrics for other sports
                st.write(f"Detailed {sport} performance analysis")
                
                # Simulated market data
                market_data = {
                    "Market": ["Match Winner", "Handicap", "Over/Under", "Prop Bets"],
                    "Accuracy": [
                        round(performance_data['sport_accuracy'][sport] + np.random.normal(0, 3), 1),
                        round(performance_data['sport_accuracy'][sport] - np.random.normal(0, 5), 1),
                        round(performance_data['sport_accuracy'][sport] - np.random.normal(0, 4), 1),
                        round(performance_data['sport_accuracy'][sport] - np.random.normal(0, 6), 1)
                    ]
                }
                market_df = pd.DataFrame(market_data)
                
                fig = px.bar(
                    market_df,
                    x="Market",
                    y="Accuracy",
                    text_auto='.1f',
                    title="Accuracy by Market Type",
                    labels={"Accuracy": "Accuracy (%)"}
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
            
            # Value analysis
            st.subheader("Value Bet Analysis")
            
            # Simulated value bet data
            odds_buckets = ["1.01-1.50", "1.51-2.00", "2.01-3.00", "3.01-5.00", "5.01+"]
            accuracy_by_odds = [round(85 - 5*i + np.random.normal(0, 2), 1) for i in range(5)]
            roi_by_odds = [round(2 + i*1.5 + np.random.normal(0, 0.5), 1) for i in range(5)]
            
            odds_data = {
                "Odds Range": odds_buckets,
                "Accuracy": accuracy_by_odds,
                "ROI": roi_by_odds
            }
            odds_df = pd.DataFrame(odds_data)
            
            fig = make_subplots(specs=[[{"secondary_y": True}]])
            
            fig.add_trace(
                go.Bar(
                    x=odds_df["Odds Range"],
                    y=odds_df["Accuracy"],
                    name="Accuracy (%)",
                    marker_color="#1E88E5"
                ),
                secondary_y=False
            )
            
            fig.add_trace(
                go.Scatter(
                    x=odds_df["Odds Range"],
                    y=odds_df["ROI"],
                    name="ROI (%)",
                    marker_color="#FF5722",
                    mode="lines+markers"
                ),
                secondary_y=True
            )
            
            fig.update_layout(
                title="Performance by Odds Range",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5)
            )
            
            fig.update_yaxes(title_text="Accuracy (%)", secondary_y=False)
            fig.update_yaxes(title_text="ROI (%)", secondary_y=True)
            
            st.plotly_chart(fig, use_container_width=True)
            
            st.markdown(f"""
            **{sport} Prediction Insights:**
            
            - Our {sport} predictions have been most accurate for match winner markets
            - Higher odds selections (3.00+) have shown better ROI despite lower accuracy
            - Predictions tend to be more accurate for higher-tier competitions
            - Home advantage factors have been slightly underestimated in our models
            
            We continuously refine our {sport} prediction algorithms based on performance data.
            """)
    
    # Prediction history
    st.markdown("---")
    st.header("Recent Predictions")
    
    if not prediction_history:
        # Create some sample prediction history if none exists
        prediction_history = [
            {
                'sport': "Soccer",
                'match': "Arsenal vs Chelsea",
                'date': "2023-11-01",
                'prediction': {
                    'home_win_prob': 45.2,
                    'draw_prob': 28.5,
                    'away_win_prob': 26.3,
                    'confidence': 72.0
                },
                'timestamp': (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                'sport': "Basketball",
                'match': "LA Lakers vs Chicago Bulls",
                'date': "2023-11-02",
                'prediction': {
                    'home_win_prob': 65.8,
                    'away_win_prob': 34.2,
                    'confidence': 68.5
                },
                'projected_score': "105-98",
                'timestamp': (datetime.now() - timedelta(days=4)).strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                'sport': "Horse Racing",
                'match': "Thunderbolt - Royal Ascot",
                'date': "2023-11-03",
                'prediction': {
                    'win_prob': 18.5,
                    'place_prob': 42.0,
                    'confidence': 65.0
                },
                'race_details': "Ascot - 2000m",
                'timestamp': (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                'sport': "Rugby",
                'match': "New Zealand vs South Africa",
                'date': "2023-11-05",
                'prediction': {
                    'home_win_prob': 52.3,
                    'draw_prob': 5.2,
                    'away_win_prob': 42.5,
                    'confidence': 78.0
                },
                'timestamp': (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
            }
        ]
        
        # Store in session state
        st.session_state.prediction_history = prediction_history
    
    if prediction_history:
        # Convert to DataFrame for display
        predictions_df = []
        
        for pred in prediction_history:
            row = {
                'Timestamp': pred['timestamp'],
                'Sport': pred['sport'],
                'Match': pred['match'],
                'Date': pred['date']
            }
            
            # Handle different prediction formats based on sport
            prediction = pred['prediction']
            if 'home_win_prob' in prediction and 'away_win_prob' in prediction:
                if 'draw_prob' in prediction:
                    row['Prediction'] = f"Home: {prediction['home_win_prob']}% | Draw: {prediction['draw_prob']}% | Away: {prediction['away_win_prob']}%"
                else:
                    row['Prediction'] = f"Home: {prediction['home_win_prob']}% | Away: {prediction['away_win_prob']}%"
            elif 'win_prob' in prediction:
                row['Prediction'] = f"Win: {prediction['win_prob']}% | Place: {prediction['place_prob']}%"
            
            row['Confidence'] = f"{prediction['confidence']}%"
            
            predictions_df.append(row)
        
        # Create DataFrame and display
        df = pd.DataFrame(predictions_df)
        st.dataframe(df, hide_index=True, use_container_width=True)
    else:
        st.info("No prediction history available yet. Make some predictions to see them here.")
    
    # Tips for improving prediction success
    st.markdown("---")
    st.header("Tips for Improving Your Success Rate")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### Betting Strategy Tips
        
        1. **Focus on sports you understand well**
        2. **Specialize in specific leagues or tournaments**
        3. **Track your performance by market type**
        4. **Consider the Kelly Criterion for stake sizing**
        5. **Be selective - quality over quantity**
        6. **Look for value, not just likely winners**
        7. **Consider closing line value as a performance metric**
        """)
    
    with col2:
        st.markdown("""
        ### Common Mistakes to Avoid
        
        1. **Chasing losses with larger bets**
        2. **Betting on too many events**
        3. **Ignoring the impact of odds movement**
        4. **Overconfidence in "sure things"**
        5. **Neglecting to shop for the best odds**
        6. **Betting based on emotion or fandom**
        7. **Failing to maintain detailed records**
        """)
    
    # FAQ section
    with st.expander("Frequently Asked Questions"):
        st.markdown("""
        **Q: How is prediction accuracy calculated?**
        
        A: Prediction accuracy is calculated as the percentage of predictions where the highest probability outcome matches the actual result.
        
        **Q: What does ROI mean in this context?**
        
        A: Return on Investment (ROI) represents the average return per unit wagered when following our predictions, expressed as a percentage.
        
        **Q: How can I use Kelly Criterion effectively?**
        
        A: The Kelly Criterion helps determine optimal bet sizes based on your edge. We recommend using "Half Kelly" (dividing the suggested stake by 2) to reduce variance while still capturing most of the growth potential.
        
        **Q: Why do some sports have higher accuracy than others?**
        
        A: Sports vary in predictability based on factors like:
        - Number of participants (team vs. individual sports)
        - Scoring frequency (high vs. low scoring)
        - Influence of random events
        - Quality and depth of available data
        
        **Q: How often are the models updated?**
        
        A: Our prediction models are continuously refined based on new data and performance metrics. Major updates typically occur on a quarterly basis.
        """)
