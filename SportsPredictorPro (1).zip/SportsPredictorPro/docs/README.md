# Sports Prediction Platform

A multi-sport prediction platform for analyzing game outcomes, comparing odds across sportsbooks, and providing statistical insights with visual data presentation.

## Features

- Multi-sport coverage (Soccer, Basketball, Rugby, Cricket, Volleyball, Horse Racing)
- Game outcome predictions with probability analysis
- Odds comparison across multiple sportsbooks
- Value bet identification
- Historical match analysis
- Bankroll management tools
- Performance tracking

## Progressive Web App

This app has been configured as a Progressive Web App (PWA), which means you can install it on your mobile device without going through an app store:

1. Open the website in Chrome or another PWA-supporting browser
2. Tap the menu button (three dots)
3. Select "Add to Home Screen" or "Install App"
4. The app will be installed on your device like a native app

## Development

This app is built using Streamlit, a Python framework for data applications.

To run it locally:

1. Clone this repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run the app: `streamlit run app.py`
