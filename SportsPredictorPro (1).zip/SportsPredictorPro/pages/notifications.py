import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Custom modules
import notifications
import utils

def show():
    """
    Display the Notifications page with alert settings and configuration
    """
    st.title("Notifications & Alerts")
    
    st.markdown("""
    Configure your betting alerts and notifications to stay updated on important events,
    odds movements, and betting opportunities.
    """)
    
    # Display main notification settings
    notifications.display_notification_settings()
    
    # Odds Alert Settings
    st.markdown("---")
    st.subheader("Odds Alert Settings")
    st.write("Set up alerts for specific odds thresholds on upcoming matches")
    
    # Get upcoming fixtures from all sports
    sports = ["Soccer", "Basketball", "Rugby", "Cricket", "Volleyball", "Horse Racing"]
    all_fixtures = []
    
    for sport in sports:
        fixtures = utils.get_upcoming_fixtures(sport, days_ahead=7)
        for fixture in fixtures:
            fixture['sport'] = sport
            all_fixtures.append(fixture)
    
    # Sorting fixtures by date and time
    sorted_fixtures = sorted(all_fixtures, key=lambda x: (x['date'], x['time']))
    
    # Filter options
    selected_sport = st.selectbox(
        "Filter by Sport", 
        ["All Sports"] + sports
    )
    
    filtered_fixtures = sorted_fixtures
    if selected_sport != "All Sports":
        filtered_fixtures = [f for f in sorted_fixtures if f['sport'] == selected_sport]
    
    # Create a fixture selection
    if filtered_fixtures:
        fixture_options = [f"{f['date']} - {f['home_team']} vs {f['away_team']} ({f['sport']})" for f in filtered_fixtures]
        selected_fixture_idx = st.selectbox("Select a Match", range(len(fixture_options)), format_func=lambda x: fixture_options[x])
        
        selected_fixture = filtered_fixtures[selected_fixture_idx]
        
        st.write(f"**Selected Match:** {selected_fixture['home_team']} vs {selected_fixture['away_team']}")
        st.write(f"**Date & Time:** {selected_fixture['date']} at {selected_fixture['time']}")
        
        # Betting options based on sport
        betting_options = ["Home Win", "Away Win"]
        if selected_fixture['sport'] in ["Soccer", "Rugby", "Cricket"]:
            betting_options.append("Draw")
        
        selected_bet_type = st.selectbox("Betting Market", betting_options)
        
        # Odds threshold
        current_odds = np.random.uniform(1.5, 4.0)  # This would be real odds in production
        min_odds = current_odds * 0.8
        max_odds = current_odds * 1.2
        
        st.write(f"Current odds for **{selected_bet_type}**: {current_odds:.2f}")
        
        target_odds = st.slider(
            "Alert me when odds reach",
            min_value=float(f"{min_odds:.2f}"),
            max_value=float(f"{max_odds:.2f}"),
            value=float(f"{current_odds:.2f}"),
            step=0.05
        )
        
        # Add alert button
        if st.button("Set Odds Alert"):
            # Check if notification settings exist
            notification_settings = notifications.get_notification_settings()
            
            if not notification_settings or not notification_settings.get('phone_number'):
                st.error("Please set up your notification settings first (phone number required)")
            else:
                # In a real app, this would be saved to a database
                # For this demo, we'll just show a success message
                
                # Create an example message
                match_info = {
                    'home_team': selected_fixture['home_team'],
                    'away_team': selected_fixture['away_team'],
                    'date': selected_fixture['date'],
                    'time': selected_fixture['time'],
                    'current_odds': f"{target_odds:.2f}",
                    'bookmaker': "Best Odds Bookmaker",
                    'recommended_stake': "5% of bankroll" 
                }
                
                example_message = notifications.create_betting_alert(
                    match_info, 
                    f"{target_odds:.2f}", 
                    selected_bet_type
                )
                
                st.success("Odds alert set successfully!")
                
                # Display example message
                st.markdown("---")
                st.subheader("Example Alert Message")
                st.code(example_message)
    else:
        st.info("No upcoming fixtures found. Please select a different sport or check back later.")
    
    # Alert History (simulated)
    st.markdown("---")
    st.subheader("Alert History")
    
    # Create sample alert history
    if 'alert_history' not in st.session_state:
        st.session_state.alert_history = generate_sample_alert_history()
    
    # Display alert history
    if st.session_state.alert_history:
        alert_df = pd.DataFrame(st.session_state.alert_history)
        st.dataframe(alert_df)
    else:
        st.info("No alert history available.")
    
    # Clear history button
    if st.button("Clear Alert History"):
        st.session_state.alert_history = []
        st.success("Alert history cleared!")
        st.rerun()

def generate_sample_alert_history():
    """Generate sample alert history for demonstration"""
    current_date = datetime.now()
    
    sample_alerts = []
    
    # Generate a few sample alerts
    for i in range(5):
        alert_date = current_date - timedelta(days=i)
        
        alert = {
            "Date": alert_date.strftime("%Y-%m-%d"),
            "Time": alert_date.strftime("%H:%M"),
            "Match": f"Team A vs Team B",
            "Alert Type": np.random.choice(["Odds Movement", "Value Bet", "Match Reminder"]),
            "Details": f"Odds changed from 2.0 to 2.4 (Bookmaker X)",
            "Sent": "Yes" if np.random.random() > 0.2 else "Failed"
        }
        
        sample_alerts.append(alert)
    
    return sample_alerts