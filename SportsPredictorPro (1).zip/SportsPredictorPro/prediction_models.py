import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
import data_processor
import random
import pickle
import os
from datetime import datetime, timedelta

# Dictionary to store trained models
models = {}

def train_soccer_model():
    """
    Train a model for soccer predictions
    In a real implementation, this would use historical data to train the model
    """
    # For MVP, we'll simulate a trained model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    
    # In a real implementation, model would be trained on historical data
    # model.fit(X_train, y_train)
    
    return model

def train_basketball_model():
    """
    Train a model for basketball predictions
    """
    # For MVP, simulate a trained model
    model = LogisticRegression(random_state=42)
    
    # In a real implementation, model would be trained on historical data
    # model.fit(X_train, y_train)
    
    return model

def get_model(sport):
    """
    Get or create a prediction model for the given sport
    """
    if sport in models:
        return models[sport]
    
    # If model doesn't exist, create one
    if sport == "Soccer":
        models[sport] = train_soccer_model()
    elif sport == "Basketball":
        models[sport] = train_basketball_model()
    elif sport == "Rugby":
        models[sport] = train_soccer_model()  # Reuse soccer model for now
    elif sport == "Cricket":
        models[sport] = train_soccer_model()  # Reuse soccer model for now
    elif sport == "Volleyball":
        models[sport] = train_basketball_model()  # Reuse basketball model for now
    elif sport == "Horse Racing":
        models[sport] = None  # Special case for horse racing
    
    return models[sport]

def predict_match(sport, match):
    """
    Predict the outcome of a match
    """
    # Get the appropriate model
    model = get_model(sport)
    
    # Get team stats for feature extraction
    home_team_stats = data_processor.get_team_stats(sport, match['home_team'])
    away_team_stats = data_processor.get_team_stats(sport, match['away_team'])
    
    # Get historical matchups
    historical_matchups = data_processor.get_historical_matchups(sport, match['home_team'], match['away_team'])
    
    # Get home/away advantage stats
    home_away_stats = data_processor.get_home_away_advantage(sport)
    
    # In a real implementation, we would:
    # 1. Extract features from team stats, historical matchups, and home/away advantage
    # 2. Use the model to predict probabilities for each outcome
    
    # For MVP, we'll simulate prediction results based on the available data
    
    if sport == "Soccer":
        # Simulated soccer prediction
        home_strength = _calculate_team_strength(home_team_stats, sport)
        away_strength = _calculate_team_strength(away_team_stats, sport)
        home_advantage = home_away_stats.get("home_win_percentage", 48.0) / 100
        
        # Adjust for historical matchups if available
        h2h_factor = _calculate_h2h_factor(historical_matchups, match['home_team'])
        
        # Calculate base probabilities
        base_home_prob = (home_strength * (1 + home_advantage)) / (home_strength * (1 + home_advantage) + away_strength + 1)
        base_away_prob = away_strength / (home_strength * (1 + home_advantage) + away_strength + 1)
        base_draw_prob = 1 - base_home_prob - base_away_prob
        
        # Apply h2h adjustment
        home_win_prob = max(min(base_home_prob * (1 + h2h_factor), 0.95), 0.05)
        away_win_prob = max(min(base_away_prob * (1 - h2h_factor), 0.95), 0.05)
        
        # Ensure probabilities sum to 1
        total = home_win_prob + away_win_prob
        home_win_prob = home_win_prob / total * (1 - base_draw_prob)
        away_win_prob = away_win_prob / total * (1 - base_draw_prob)
        draw_prob = base_draw_prob
        
        # Round to 1 decimal place
        home_win_prob = round(home_win_prob * 100, 1)
        away_win_prob = round(away_win_prob * 100, 1)
        draw_prob = round(draw_prob * 100, 1)
        
        # Calculate confidence based on data quality and model certainty
        confidence = round(min(max(70 + random.normalvariate(0, 5), 50), 95), 1)
        
        # Key factors influencing the prediction
        key_factors = _generate_key_factors(sport, home_team_stats, away_team_stats, home_win_prob > away_win_prob)
        
        return {
            "home_win_prob": home_win_prob,
            "away_win_prob": away_win_prob,
            "draw_prob": draw_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    elif sport == "Basketball":
        # Simulated basketball prediction
        home_strength = _calculate_team_strength(home_team_stats, sport)
        away_strength = _calculate_team_strength(away_team_stats, sport)
        home_advantage = home_away_stats.get("home_win_percentage", 58.0) / 100
        
        # Adjust for historical matchups if available
        h2h_factor = _calculate_h2h_factor(historical_matchups, match['home_team'])
        
        # Calculate probabilities
        base_home_prob = (home_strength * (1 + home_advantage)) / (home_strength * (1 + home_advantage) + away_strength)
        base_away_prob = away_strength / (home_strength * (1 + home_advantage) + away_strength)
        
        # Apply h2h adjustment
        home_win_prob = max(min(base_home_prob * (1 + h2h_factor), 0.95), 0.05)
        away_win_prob = max(min(base_away_prob * (1 - h2h_factor), 0.95), 0.05)
        
        # Ensure probabilities sum to 1
        total = home_win_prob + away_win_prob
        home_win_prob = home_win_prob / total
        away_win_prob = away_win_prob / total
        
        # Round to 1 decimal place
        home_win_prob = round(home_win_prob * 100, 1)
        away_win_prob = round(away_win_prob * 100, 1)
        
        # Calculate confidence based on data quality and model certainty
        confidence = round(min(max(75 + random.normalvariate(0, 5), 50), 95), 1)
        
        # Key factors influencing the prediction
        key_factors = _generate_key_factors(sport, home_team_stats, away_team_stats, home_win_prob > away_win_prob)
        
        return {
            "home_win_prob": home_win_prob,
            "away_win_prob": away_win_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    elif sport == "Rugby":
        # Similar approach as soccer but with rugby-specific adjustments
        home_strength = _calculate_team_strength(home_team_stats, sport)
        away_strength = _calculate_team_strength(away_team_stats, sport)
        home_advantage = home_away_stats.get("home_win_percentage", 60.0) / 100
        
        h2h_factor = _calculate_h2h_factor(historical_matchups, match['home_team'])
        
        base_home_prob = (home_strength * (1 + home_advantage)) / (home_strength * (1 + home_advantage) + away_strength + 0.5)
        base_away_prob = away_strength / (home_strength * (1 + home_advantage) + away_strength + 0.5)
        base_draw_prob = 1 - base_home_prob - base_away_prob
        
        home_win_prob = max(min(base_home_prob * (1 + h2h_factor), 0.95), 0.05)
        away_win_prob = max(min(base_away_prob * (1 - h2h_factor), 0.95), 0.05)
        
        total = home_win_prob + away_win_prob
        home_win_prob = home_win_prob / total * (1 - base_draw_prob)
        away_win_prob = away_win_prob / total * (1 - base_draw_prob)
        draw_prob = base_draw_prob
        
        home_win_prob = round(home_win_prob * 100, 1)
        away_win_prob = round(away_win_prob * 100, 1)
        draw_prob = round(draw_prob * 100, 1)
        
        confidence = round(min(max(72 + random.normalvariate(0, 5), 50), 95), 1)
        
        key_factors = _generate_key_factors(sport, home_team_stats, away_team_stats, home_win_prob > away_win_prob)
        
        return {
            "home_win_prob": home_win_prob,
            "away_win_prob": away_win_prob,
            "draw_prob": draw_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    elif sport == "Cricket":
        # Cricket prediction
        home_strength = _calculate_team_strength(home_team_stats, sport)
        away_strength = _calculate_team_strength(away_team_stats, sport)
        home_advantage = home_away_stats.get("home_win_percentage", 54.0) / 100
        
        h2h_factor = _calculate_h2h_factor(historical_matchups, match['home_team'])
        
        base_home_prob = (home_strength * (1 + home_advantage)) / (home_strength * (1 + home_advantage) + away_strength + 0.7)
        base_away_prob = away_strength / (home_strength * (1 + home_advantage) + away_strength + 0.7)
        base_draw_prob = 1 - base_home_prob - base_away_prob
        
        home_win_prob = max(min(base_home_prob * (1 + h2h_factor), 0.95), 0.05)
        away_win_prob = max(min(base_away_prob * (1 - h2h_factor), 0.95), 0.05)
        
        total = home_win_prob + away_win_prob
        home_win_prob = home_win_prob / total * (1 - base_draw_prob)
        away_win_prob = away_win_prob / total * (1 - base_draw_prob)
        draw_prob = base_draw_prob
        
        home_win_prob = round(home_win_prob * 100, 1)
        away_win_prob = round(away_win_prob * 100, 1)
        draw_prob = round(draw_prob * 100, 1)
        
        confidence = round(min(max(68 + random.normalvariate(0, 5), 50), 95), 1)
        
        key_factors = _generate_key_factors(sport, home_team_stats, away_team_stats, home_win_prob > away_win_prob)
        
        return {
            "home_win_prob": home_win_prob,
            "away_win_prob": away_win_prob,
            "draw_prob": draw_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    elif sport == "Volleyball":
        # Volleyball prediction
        home_strength = _calculate_team_strength(home_team_stats, sport)
        away_strength = _calculate_team_strength(away_team_stats, sport)
        home_advantage = home_away_stats.get("home_win_percentage", 62.0) / 100
        
        h2h_factor = _calculate_h2h_factor(historical_matchups, match['home_team'])
        
        base_home_prob = (home_strength * (1 + home_advantage)) / (home_strength * (1 + home_advantage) + away_strength)
        base_away_prob = away_strength / (home_strength * (1 + home_advantage) + away_strength)
        
        home_win_prob = max(min(base_home_prob * (1 + h2h_factor), 0.95), 0.05)
        away_win_prob = max(min(base_away_prob * (1 - h2h_factor), 0.95), 0.05)
        
        total = home_win_prob + away_win_prob
        home_win_prob = home_win_prob / total
        away_win_prob = away_win_prob / total
        
        home_win_prob = round(home_win_prob * 100, 1)
        away_win_prob = round(away_win_prob * 100, 1)
        
        confidence = round(min(max(72 + random.normalvariate(0, 5), 50), 95), 1)
        
        key_factors = _generate_key_factors(sport, home_team_stats, away_team_stats, home_win_prob > away_win_prob)
        
        return {
            "home_win_prob": home_win_prob,
            "away_win_prob": away_win_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    elif sport == "Horse Racing":
        # Horse racing is different as it involves multiple competitors
        # For MVP, we'll simulate a simple win probability
        
        # Assuming 'match' contains information about a specific horse race
        # and we want to predict for a specific horse
        horse_name = match.get('horse_name', match.get('home_team', ''))
        horse_stats = home_team_stats  # Reusing the variable name
        
        # Calculate base probability based on past performance
        if 'win_percentage' in horse_stats:
            base_prob = horse_stats['win_percentage'] / 100
        else:
            base_prob = 0.2  # Default probability
        
        # Adjust for recent form
        if 'last_5_finishes' in horse_stats:
            recent_form_factor = sum([1 if finish == 1 else 0.3 if finish <= 3 else 0 
                                     for finish in horse_stats['last_5_finishes']]) / 5
            win_prob = base_prob * (0.7 + 0.3 * recent_form_factor)
        else:
            win_prob = base_prob
        
        # Add some randomness for other factors
        win_prob = min(max(win_prob * (1 + random.normalvariate(0, 0.1)), 0.01), 0.6)
        
        place_prob = win_prob * 1.8  # Probability of finishing in the top 3
        place_prob = min(place_prob, 0.85)
        
        win_prob = round(win_prob * 100, 1)
        place_prob = round(place_prob * 100, 1)
        
        confidence = round(min(max(65 + random.normalvariate(0, 5), 50), 90), 1)
        
        # Horse racing specific factors
        key_factors = [
            f"Recent form: {', '.join([str(f) for f in horse_stats.get('last_5_finishes', [0][:5])])}",
            f"Win rate: {horse_stats.get('win_percentage', 0)}%",
            f"Preferred distance: {horse_stats.get('best_distance', 'Unknown')}",
            f"Track condition preference: {horse_stats.get('track_preference', 'Unknown')}"
        ]
        
        return {
            "win_prob": win_prob,
            "place_prob": place_prob,
            "confidence": confidence,
            "key_factors": key_factors
        }
    
    # Default empty prediction
    return None

def _calculate_team_strength(team_stats, sport):
    """
    Calculate a team's strength score based on its stats
    """
    if not team_stats:
        return 1.0  # Default value if no stats available
    
    if sport == "Soccer":
        if 'ppg' in team_stats:
            return team_stats['ppg']
        else:
            wins = team_stats.get('wins', 0)
            draws = team_stats.get('draws', 0)
            matches = team_stats.get('matches_played', 1)
            return (wins * 3 + draws) / (matches * 3)
    
    elif sport == "Basketball":
        wins = team_stats.get('wins', 0)
        losses = team_stats.get('losses', 1)
        return wins / (wins + losses)
    
    elif sport == "Rugby":
        wins = team_stats.get('wins', 0)
        draws = team_stats.get('draws', 0)
        matches = team_stats.get('matches_played', 1)
        return (wins * 3 + draws) / (matches * 3)
    
    elif sport == "Cricket":
        wins = team_stats.get('wins', 0)
        matches = team_stats.get('matches_played', 1)
        return wins / matches
    
    elif sport == "Volleyball":
        wins = team_stats.get('wins', 0)
        matches = team_stats.get('matches_played', 1)
        return wins / matches
    
    # Default formula
    return 0.5

def _calculate_h2h_factor(historical_matchups, home_team):
    """
    Calculate a factor based on head-to-head history
    Positive value means home team has an advantage, negative means away team
    """
    if not historical_matchups or len(historical_matchups) == 0:
        return 0
    
    home_wins = 0
    away_wins = 0
    
    for match in historical_matchups:
        if match['home_team'] == home_team:
            if isinstance(match['home_score'], (int, float)) and isinstance(match['away_score'], (int, float)):
                if match['home_score'] > match['away_score']:
                    home_wins += 1
                elif match['home_score'] < match['away_score']:
                    away_wins += 1
        else:
            if isinstance(match['home_score'], (int, float)) and isinstance(match['away_score'], (int, float)):
                if match['home_score'] < match['away_score']:
                    home_wins += 1
                elif match['home_score'] > match['away_score']:
                    away_wins += 1
    
    total_decisive_matches = home_wins + away_wins
    
    if total_decisive_matches == 0:
        return 0
    
    # Return a value between -0.2 and 0.2
    return 0.2 * (home_wins - away_wins) / total_decisive_matches

def _generate_key_factors(sport, home_stats, away_stats, home_favored):
    """
    Generate key factors that influence the prediction
    """
    factors = []
    
    if sport == "Soccer":
        if home_favored:
            if home_stats.get('home_form', []).count("W") > away_stats.get('away_form', []).count("W"):
                factors.append(f"{home_stats['team_name']} has better home form than {away_stats['team_name']}'s away form")
            
            if home_stats.get('goals_scored', 0) > away_stats.get('goals_scored', 0):
                factors.append(f"{home_stats['team_name']} has scored more goals this season")
            
            if home_stats.get('clean_sheets', 0) > away_stats.get('clean_sheets', 0):
                factors.append(f"{home_stats['team_name']} has more clean sheets")
        else:
            if away_stats.get('away_form', []).count("W") > home_stats.get('home_form', []).count("W"):
                factors.append(f"{away_stats['team_name']} has better away form than {home_stats['team_name']}'s home form")
            
            if away_stats.get('goals_scored', 0) > home_stats.get('goals_scored', 0):
                factors.append(f"{away_stats['team_name']} has scored more goals this season")
            
            if away_stats.get('xG', 0) > home_stats.get('xG', 0):
                factors.append(f"{away_stats['team_name']} has higher expected goals (xG)")
        
        # Common factors
        factors.append("Home advantage is a significant factor")
        
        if len(factors) < 3:
            factors.append("Recent team form and historical performance")
    
    elif sport == "Basketball":
        if home_favored:
            if home_stats.get('pts_per_game', 0) > away_stats.get('pts_per_game', 0):
                factors.append(f"{home_stats['team_name']} scores more points per game")
            
            if home_stats.get('fg_percentage', 0) > away_stats.get('fg_percentage', 0):
                factors.append(f"{home_stats['team_name']} has a better field goal percentage")
            
            if home_stats.get('form', []).count("W") > away_stats.get('form', []).count("W"):
                factors.append(f"{home_stats['team_name']} has better recent form")
        else:
            if away_stats.get('pts_per_game', 0) > home_stats.get('pts_per_game', 0):
                factors.append(f"{away_stats['team_name']} scores more points per game")
            
            if away_stats.get('fg_percentage', 0) > home_stats.get('fg_percentage', 0):
                factors.append(f"{away_stats['team_name']} has a better field goal percentage")
            
            if away_stats.get('form', []).count("W") > home_stats.get('form', []).count("W"):
                factors.append(f"{away_stats['team_name']} has better recent form")
        
        # Common factors
        factors.append("Home court advantage is significant in basketball")
        
        if len(factors) < 3:
            factors.append("Team depth and defensive performance")
    
    # Add generic factors if we don't have enough
    if len(factors) < 3:
        factors.append("Team composition and player availability")
        factors.append("Historical head-to-head performance")
    
    return factors[:4]  # Return at most 4 factors
