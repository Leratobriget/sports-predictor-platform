import os
import streamlit as st
from datetime import datetime
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException

# Twilio credentials
def get_twilio_credentials():
    """Get Twilio credentials from environment variables"""
    return {
        'account_sid': os.environ.get('TWILIO_ACCOUNT_SID'),
        'auth_token': os.environ.get('TWILIO_AUTH_TOKEN'),
        'phone_number': os.environ.get('TWILIO_PHONE_NUMBER')
    }

def check_twilio_setup():
    """Check if Twilio credentials are properly set up"""
    credentials = get_twilio_credentials()
    
    # Check if any credential is missing
    missing_credentials = [key for key, value in credentials.items() if not value]
    
    if missing_credentials:
        missing_vars = ', '.join([f"'{key.upper()}'" for key in missing_credentials])
        return False, f"Twilio credentials missing: {missing_vars}"
    
    return True, "Twilio credentials are set up correctly"

def send_sms_alert(to_phone_number, message):
    """
    Send an SMS alert using Twilio
    
    Args:
        to_phone_number (str): The recipient's phone number in E.164 format (e.g., +1234567890)
        message (str): The SMS message content
        
    Returns:
        bool, str: Success status and message
    """
    # Validate phone number format
    if not to_phone_number.startswith('+'):
        return False, "Phone number must be in E.164 format (e.g., +1234567890)"
    
    credentials = get_twilio_credentials()
    
    # Check if credentials are available
    is_setup, setup_message = check_twilio_setup()
    if not is_setup:
        return False, setup_message
    
    try:
        # Initialize Twilio client
        client = Client(credentials['account_sid'], credentials['auth_token'])
        
        # Send message
        twilio_message = client.messages.create(
            body=message,
            from_=credentials['phone_number'],
            to=to_phone_number
        )
        
        # Return success with message SID
        return True, f"Message sent successfully! SID: {twilio_message.sid}"
        
    except TwilioRestException as e:
        # Handle Twilio-specific errors
        return False, f"Twilio error: {str(e)}"
    except Exception as e:
        # Handle general errors
        return False, f"Error sending message: {str(e)}"

def save_notification_settings(phone_number, events):
    """Save notification preferences to session state"""
    if 'notification_settings' not in st.session_state:
        st.session_state.notification_settings = {}
    
    st.session_state.notification_settings['phone_number'] = phone_number
    st.session_state.notification_settings['events'] = events
    st.session_state.notification_settings['last_updated'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    return True

def get_notification_settings():
    """Get the current notification settings"""
    if 'notification_settings' not in st.session_state:
        return None
    
    return st.session_state.notification_settings

def create_betting_alert(match_info, odds_threshold, bet_type):
    """
    Create a customized betting alert message
    
    Args:
        match_info (dict): Match information dictionary
        odds_threshold (float): The odds threshold that triggered the alert
        bet_type (str): Type of bet (e.g., "Home Win", "Away Win", "Draw")
        
    Returns:
        str: Formatted alert message
    """
    current_time = datetime.now().strftime("%H:%M")
    
    message = f"🔔 BETTING ALERT [{current_time}]\n\n"
    message += f"{match_info['home_team']} vs {match_info['away_team']}\n"
    message += f"📅 {match_info['date']} | ⏰ {match_info['time']}\n\n"
    message += f"✅ {bet_type} odds have reached your target of {odds_threshold}!\n"
    message += f"Current odds: {match_info['current_odds']}\n"
    message += f"Bookmaker: {match_info['bookmaker']}\n\n"
    message += f"Recommended stake: {match_info.get('recommended_stake', 'N/A')}\n"
    message += "Open app for more details"
    
    return message

def display_notification_settings():
    """Display and manage notification settings in the app"""
    st.subheader("Betting Alerts & Notifications")
    
    # Check Twilio setup
    is_setup, setup_message = check_twilio_setup()
    
    if not is_setup:
        st.warning(setup_message)
        st.info("Twilio credentials are required to send SMS alerts. Please ask the administrator to set up the required environment variables.")
    
    # Current settings
    current_settings = get_notification_settings()
    current_phone = current_settings.get('phone_number', '') if current_settings else ''
    current_events = current_settings.get('events', []) if current_settings else []
    
    # Phone number input
    phone_number = st.text_input(
        "Your phone number (in E.164 format, e.g., +1234567890)",
        value=current_phone
    )
    
    # Notification options
    st.write("Select events to receive alerts for:")
    
    notification_options = {
        "value_bets": "Value bet opportunities (when our model gives you an edge)",
        "odds_movement": "Significant odds movements",
        "team_news": "Important team news (injuries, lineup changes)",
        "match_start": "Match start reminders",
        "bankroll_updates": "Weekly bankroll performance updates"
    }
    
    selected_events = []
    for event_key, event_description in notification_options.items():
        is_selected = event_key in current_events if current_events else False
        if st.checkbox(event_description, value=is_selected, key=f"notif_{event_key}"):
            selected_events.append(event_key)
    
    # Save settings
    if st.button("Save Notification Settings"):
        if not phone_number or not phone_number.startswith('+'):
            st.error("Please enter a valid phone number in E.164 format (starting with +)")
        elif not selected_events:
            st.warning("Please select at least one type of notification")
        else:
            save_notification_settings(phone_number, selected_events)
            st.success("Notification settings saved successfully!")
    
    # Test notification
    st.markdown("---")
    if st.button("Send Test Alert"):
        if not phone_number or not phone_number.startswith('+'):
            st.error("Please enter a valid phone number in E.164 format (starting with +)")
        else:
            test_message = ("🔔 TEST ALERT\n\nThis is a test alert from your Sports Prediction Platform. "
                           "If you received this message, your alerts are set up correctly!")
            
            success, message = send_sms_alert(phone_number, test_message)
            
            if success:
                st.success(message)
            else:
                st.error(message)
    
    # Display current settings
    if current_settings:
        st.markdown("---")
        st.subheader("Current Notification Settings")
        st.write(f"Phone Number: {current_settings['phone_number']}")
        st.write(f"Notification Types: {', '.join(current_settings['events'])}")
        st.write(f"Last Updated: {current_settings['last_updated']}")