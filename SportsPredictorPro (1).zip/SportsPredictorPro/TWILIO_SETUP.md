# Setting Up Twilio for SMS Notifications

Your Sports Prediction Platform includes SMS notification capabilities powered by Twilio. To enable this feature, you'll need to set up a Twilio account and obtain the necessary credentials.

## Step 1: Create a Twilio Account

1. Go to [Twilio's website](https://www.twilio.com/try-twilio) and sign up for a free account
2. Verify your email address and phone number

## Step 2: Get Your Twilio Credentials

1. After signing in to your Twilio dashboard, locate the following credentials:
   - **Account SID**: Found on your Twilio dashboard
   - **Auth Token**: Found on your Twilio dashboard (click on "Show")
   - **Twilio Phone Number**: You'll need to get a Twilio phone number from the "Phone Numbers" section

## Step 3: Set Up Environment Variables

### For Local Development:

Create a file named `.streamlit/secrets.toml` in your project directory with the following content:

```toml
# .streamlit/secrets.toml
TWILIO_ACCOUNT_SID = "your_account_sid_here"
TWILIO_AUTH_TOKEN = "your_auth_token_here"
TWILIO_PHONE_NUMBER = "your_twilio_phone_number_here"
```

### For Streamlit Cloud Deployment:

1. Go to your app's dashboard on Streamlit Cloud
2. Navigate to "Settings" > "Secrets"
3. Add the following secrets:
   ```
   TWILIO_ACCOUNT_SID = "your_account_sid_here"
   TWILIO_AUTH_TOKEN = "your_auth_token_here"
   TWILIO_PHONE_NUMBER = "your_twilio_phone_number_here"
   ```

## Notes About Free Twilio Accounts

- Free Twilio trial accounts can only send SMS messages to verified phone numbers
- To verify a phone number, add it in your Twilio console under "Verified Caller IDs"
- For production use with unrestricted messaging, you'll need to upgrade your Twilio account

## Testing Your Setup

1. Log in to your Sports Prediction Platform
2. Go to the "Notifications" page
3. Enter your phone number in E.164 format (e.g., +1234567890)
4. Select which alerts you want to receive
5. Click "Send Test Alert" to confirm everything is working