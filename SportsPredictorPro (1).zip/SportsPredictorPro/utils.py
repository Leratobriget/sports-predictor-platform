import streamlit as st
import os
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
import data_processor

def check_api_keys():
    """
    Check if necessary API keys are set in environment variables
    """
    required_keys = {
        "SPORTS_DATA_API_KEY": os.getenv("SPORTS_DATA_API_KEY"),
        "ODDS_API_KEY": os.getenv("ODDS_API_KEY"),
        "FOOTBALL_DATA_API_KEY": os.getenv("FOOTBALL_DATA_API_KEY")
    }
    
    missing_keys = [key for key, value in required_keys.items() if not value]
    
    if missing_keys:
        message = "⚠️ Some API keys are missing. Functionality may be limited. Missing keys: " + ", ".join(missing_keys)
        st.session_state.api_error = message
        return False
    else:
        st.session_state.api_error = None
        return True

def format_odds(odds):
    """
    Format decimal odds for display
    """
    if not odds:
        return "N/A"
    
    try:
        return f"{float(odds):.2f}"
    except:
        return str(odds)

def save_prediction(prediction_data):
    """
    Save a prediction to the prediction history
    """
    # In a real app, this would save to a database
    # For MVP, we'll save to session state
    
    if 'prediction_history' not in st.session_state:
        st.session_state.prediction_history = []
    
    # Add timestamp
    prediction_data['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Add to history
    st.session_state.prediction_history.append(prediction_data)
    
    # Limit history size
    if len(st.session_state.prediction_history) > 100:
        st.session_state.prediction_history = st.session_state.prediction_history[-100:]

def get_prediction_history():
    """
    Get prediction history from session state
    """
    if 'prediction_history' not in st.session_state:
        st.session_state.prediction_history = []
    
    return st.session_state.prediction_history

def get_bankroll_data():
    """
    Get bankroll management data from session state
    """
    if 'bankroll' not in st.session_state:
        # Initialize with default values
        st.session_state.bankroll = {
            'current_bankroll': 1000,
            'starting_bankroll': 1000,
            'risk_percentage': 2,
            'history': {
                (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"): 1000,
                (datetime.now() - timedelta(days=25)).strftime("%Y-%m-%d"): 1050,
                (datetime.now() - timedelta(days=20)).strftime("%Y-%m-%d"): 1120,
                (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d"): 1090,
                (datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"): 1150,
                (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"): 1180,
                datetime.now().strftime("%Y-%m-%d"): 1220
            },
            'bets': []
        }
    
    return st.session_state.bankroll

def update_bankroll(amount_change, bet_info=None):
    """
    Update the bankroll amount
    """
    bankroll_data = get_bankroll_data()
    
    # Update current bankroll
    bankroll_data['current_bankroll'] += amount_change
    
    # Add to history if it's a new day
    today = datetime.now().strftime("%Y-%m-%d")
    bankroll_data['history'][today] = bankroll_data['current_bankroll']
    
    # Add bet to history if provided
    if bet_info:
        bet_info['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        bet_info['bankroll_after'] = bankroll_data['current_bankroll']
        bankroll_data['bets'].append(bet_info)
    
    # Update session state
    st.session_state.bankroll = bankroll_data

def calculate_bet_amount(bankroll, risk_percentage, kelly=None):
    """
    Calculate bet amount based on bankroll and risk percentage
    Optionally use Kelly Criterion if provided
    """
    if kelly is not None:
        # Use Kelly fraction but limit to risk percentage
        stake_percentage = min(kelly * 100, risk_percentage)
    else:
        stake_percentage = risk_percentage
    
    return (bankroll * stake_percentage) / 100

def get_upcoming_fixtures(sport, days_ahead=7):
    """
    Get upcoming fixtures for a sport over the next X days
    """
    fixtures = []
    
    today = datetime.now().date()
    
    for i in range(days_ahead):
        current_date = today + timedelta(days=i)
        daily_fixtures = data_processor.get_upcoming_matches(sport, current_date)
        
        if daily_fixtures:
            for fixture in daily_fixtures:
                fixture['date_obj'] = current_date
                fixtures.append(fixture)
    
    return fixtures

def get_sport_emoji(sport):
    """
    Return an emoji for each sport
    """
    emojis = {
        "Soccer": "⚽",
        "Basketball": "🏀",
        "Rugby": "🏉",
        "Cricket": "🏏",
        "Volleyball": "🏐",
        "Horse Racing": "🏇"
    }
    
    return emojis.get(sport, "🏆")

def convert_odds_format(decimal_odds, format_type="decimal"):
    """
    Convert between odds formats
    """
    if not decimal_odds or decimal_odds <= 1:
        return "N/A"
    
    if format_type == "decimal":
        return f"{decimal_odds:.2f}"
    
    elif format_type == "fractional":
        # Convert decimal to fractional
        decimal_part = decimal_odds - 1
        
        # Find a reasonable approximation as a fraction
        precision = 2
        numerator = round(decimal_part * 10**precision)
        denominator = 10**precision
        
        # Reduce the fraction
        from math import gcd
        common_divisor = gcd(numerator, denominator)
        numerator = numerator // common_divisor
        denominator = denominator // common_divisor
        
        return f"{numerator}/{denominator}"
    
    elif format_type == "american":
        # Convert decimal to american
        if decimal_odds >= 2:
            # Positive American odds (underdog)
            return f"+{int((decimal_odds - 1) * 100)}"
        else:
            # Negative American odds (favorite)
            return f"-{int(100 / (decimal_odds - 1))}"
    
    # Default to decimal if invalid format
    return f"{decimal_odds:.2f}"
