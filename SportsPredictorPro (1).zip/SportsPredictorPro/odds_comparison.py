import requests
import pandas as pd
import numpy as np
import os
import time
import json
from datetime import datetime

# API key for The Odds API or similar service
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "")

# Cache for API responses (TTL: 15 minutes)
odds_cache = {}
CACHE_TTL = 900  # 15 minutes

def get_odds_comparison(sport, match):
    """
    Get odds comparison across multiple sportsbooks for a given match
    """
    # Generate a cache key based on sport and match
    cache_key = f"{sport}_{match.get('id', '')}_{match.get('home_team', '')}_{match.get('away_team', '')}"
    
    # Check if we have a valid cached response
    if cache_key in odds_cache:
        cache_time, cache_data = odds_cache[cache_key]
        if time.time() - cache_time < CACHE_TTL:
            return cache_data
    
    # For a real application, we would call an odds API like The Odds API
    # Example: https://api.the-odds-api.com/v4/sports/soccer_epl/odds
    
    # For MVP, we'll return simulated odds data
    bookmakers = ["Bet365", "Betway", "William Hill", "Paddy Power", "888sport", 
                 "Unibet", "10Bet", "BetVictor", "Ladbrokes", "Coral", "Betfair", "SkyBet"]
    
    odds_data = []
    
    if sport == "Soccer":
        # Soccer has 1X2 odds (home, draw, away)
        # Generate realistic odds with small variations between bookmakers
        
        # Base odds - these would come from the API in a real implementation
        base_home_odds = 2.05 + np.random.normal(0, 0.1)
        base_draw_odds = 3.40 + np.random.normal(0, 0.15)
        base_away_odds = 3.60 + np.random.normal(0, 0.2)
        
        for bookmaker in bookmakers:
            # Add small random variations for each bookmaker
            home_odds = round(max(1.01, base_home_odds + np.random.normal(0, 0.08)), 2)
            draw_odds = round(max(1.01, base_draw_odds + np.random.normal(0, 0.1)), 2)
            away_odds = round(max(1.01, base_away_odds + np.random.normal(0, 0.12)), 2)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "home_win": home_odds,
                "draw": draw_odds,
                "away_win": away_odds,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    elif sport == "Basketball":
        # Basketball typically has moneyline odds (home, away)
        
        # Base odds
        base_home_odds = 1.85 + np.random.normal(0, 0.08)
        base_away_odds = 1.95 + np.random.normal(0, 0.1)
        
        # Also include spread and total points
        base_spread = 5.5 if np.random.random() > 0.5 else 6.5
        base_spread_odds = 1.91 + np.random.normal(0, 0.03)
        base_total_points = 220.5 if np.random.random() > 0.5 else 219.5
        base_over_under_odds = 1.91 + np.random.normal(0, 0.03)
        
        for bookmaker in bookmakers:
            # Add small random variations for each bookmaker
            home_odds = round(max(1.01, base_home_odds + np.random.normal(0, 0.05)), 2)
            away_odds = round(max(1.01, base_away_odds + np.random.normal(0, 0.06)), 2)
            
            # Spread and totals also vary slightly
            spread = base_spread + (0.5 if np.random.random() > 0.85 else 0)
            total_points = base_total_points + (1 if np.random.random() > 0.85 else 0)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "home_win": home_odds,
                "away_win": away_odds,
                "spread": f"{match['home_team']} {-spread if np.random.random() > 0.5 else spread}",
                "spread_odds": round(max(1.01, base_spread_odds + np.random.normal(0, 0.02)), 2),
                "total_points": total_points,
                "over_odds": round(max(1.01, base_over_under_odds + np.random.normal(0, 0.02)), 2),
                "under_odds": round(max(1.01, base_over_under_odds + np.random.normal(0, 0.02)), 2),
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    elif sport == "Rugby":
        # Rugby similar to soccer (1X2)
        base_home_odds = 1.75 + np.random.normal(0, 0.1)
        base_draw_odds = 20.0 + np.random.normal(0, 1.5)  # Draws are rare in rugby
        base_away_odds = 2.10 + np.random.normal(0, 0.15)
        
        for bookmaker in bookmakers:
            home_odds = round(max(1.01, base_home_odds + np.random.normal(0, 0.08)), 2)
            draw_odds = round(max(10.0, base_draw_odds + np.random.normal(0, 1.0)), 2)
            away_odds = round(max(1.01, base_away_odds + np.random.normal(0, 0.1)), 2)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "home_win": home_odds,
                "draw": draw_odds,
                "away_win": away_odds,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    elif sport == "Cricket":
        # Cricket typically has match winner odds
        base_home_odds = 1.90 + np.random.normal(0, 0.1)
        base_draw_odds = 4.50 + np.random.normal(0, 0.2)  # Draws in test cricket
        base_away_odds = 2.00 + np.random.normal(0, 0.12)
        
        for bookmaker in bookmakers:
            home_odds = round(max(1.01, base_home_odds + np.random.normal(0, 0.08)), 2)
            draw_odds = round(max(1.01, base_draw_odds + np.random.normal(0, 0.15)), 2)
            away_odds = round(max(1.01, base_away_odds + np.random.normal(0, 0.1)), 2)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "home_win": home_odds,
                "draw": draw_odds,
                "away_win": away_odds,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    elif sport == "Volleyball":
        # Volleyball typically just has match winner odds
        base_home_odds = 1.65 + np.random.normal(0, 0.08)
        base_away_odds = 2.30 + np.random.normal(0, 0.12)
        
        for bookmaker in bookmakers:
            home_odds = round(max(1.01, base_home_odds + np.random.normal(0, 0.05)), 2)
            away_odds = round(max(1.01, base_away_odds + np.random.normal(0, 0.08)), 2)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "home_win": home_odds,
                "away_win": away_odds,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    elif sport == "Horse Racing":
        # Horse racing has different odds format
        # We'll simulate odds for a single horse in a race
        
        # This would typically come from the API
        horse_name = match.get('horse_name', match.get('home_team', ''))
        
        base_win_odds = 6.50 + np.random.normal(0, 0.5)
        base_place_odds = 2.20 + np.random.normal(0, 0.2)
        
        for bookmaker in bookmakers:
            win_odds = round(max(1.01, base_win_odds + np.random.normal(0, 0.3)), 2)
            place_odds = round(max(1.01, base_place_odds + np.random.normal(0, 0.1)), 2)
            
            odds_data.append({
                "bookmaker": bookmaker,
                "horse": horse_name,
                "win_odds": win_odds,
                "place_odds": place_odds,
                "last_update": datetime.now().strftime("%Y-%m-%d %H:%M")
            })
    
    # Cache the results
    odds_cache[cache_key] = (time.time(), odds_data)
    
    return odds_data

def get_best_odds(odds_data):
    """
    Find the best available odds for each outcome
    """
    if not odds_data or len(odds_data) == 0:
        return {}
    
    # Initialize best odds dictionary
    best_odds = {}
    
    # Check what type of odds we're dealing with
    if "draw" in odds_data[0]:
        # 1X2 market (home, draw, away)
        best_home_odds = max(odds_data, key=lambda x: x.get("home_win", 0))
        best_draw_odds = max(odds_data, key=lambda x: x.get("draw", 0))
        best_away_odds = max(odds_data, key=lambda x: x.get("away_win", 0))
        
        best_odds = {
            "home_win": {
                "odds": best_home_odds.get("home_win"),
                "bookmaker": best_home_odds.get("bookmaker")
            },
            "draw": {
                "odds": best_draw_odds.get("draw"),
                "bookmaker": best_draw_odds.get("bookmaker")
            },
            "away_win": {
                "odds": best_away_odds.get("away_win"),
                "bookmaker": best_away_odds.get("bookmaker")
            }
        }
    
    elif "horse" in odds_data[0]:
        # Horse racing
        best_win_odds = max(odds_data, key=lambda x: x.get("win_odds", 0))
        best_place_odds = max(odds_data, key=lambda x: x.get("place_odds", 0))
        
        best_odds = {
            "win": {
                "odds": best_win_odds.get("win_odds"),
                "bookmaker": best_win_odds.get("bookmaker")
            },
            "place": {
                "odds": best_place_odds.get("place_odds"),
                "bookmaker": best_place_odds.get("bookmaker")
            }
        }
    
    else:
        # Moneyline market (home, away)
        best_home_odds = max(odds_data, key=lambda x: x.get("home_win", 0))
        best_away_odds = max(odds_data, key=lambda x: x.get("away_win", 0))
        
        best_odds = {
            "home_win": {
                "odds": best_home_odds.get("home_win"),
                "bookmaker": best_home_odds.get("bookmaker")
            },
            "away_win": {
                "odds": best_away_odds.get("away_win"),
                "bookmaker": best_away_odds.get("bookmaker")
            }
        }
    
    return best_odds

def identify_value_bets(odds_data, prediction):
    """
    Identify value bets based on our prediction model vs. bookmaker odds
    """
    if not odds_data or not prediction:
        return []
    
    value_bets = []
    
    # For each outcome, check if our predicted probability implies better odds than bookmakers offer
    if "draw_prob" in prediction:
        # 1X2 market (soccer, rugby, etc.)
        
        # Convert probabilities to fair odds
        fair_home_odds = 100 / prediction["home_win_prob"] if prediction["home_win_prob"] > 0 else 999
        fair_draw_odds = 100 / prediction["draw_prob"] if prediction["draw_prob"] > 0 else 999
        fair_away_odds = 100 / prediction["away_win_prob"] if prediction["away_win_prob"] > 0 else 999
        
        # Find best available odds
        best_odds = get_best_odds(odds_data)
        
        # Check for value (if bookmaker odds > fair odds)
        if "home_win" in best_odds and best_odds["home_win"]["odds"] > fair_home_odds:
            edge_percentage = (best_odds["home_win"]["odds"] / fair_home_odds - 1) * 100
            if edge_percentage > 5:  # Only suggest if edge is significant
                value_bets.append({
                    "bet_type": "Home Win",
                    "bookmaker": best_odds["home_win"]["bookmaker"],
                    "odds": best_odds["home_win"]["odds"],
                    "fair_odds": fair_home_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Home Win at odds of {best_odds['home_win']['odds']} with {best_odds['home_win']['bookmaker']}"
                })
        
        if "draw" in best_odds and best_odds["draw"]["odds"] > fair_draw_odds:
            edge_percentage = (best_odds["draw"]["odds"] / fair_draw_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Draw",
                    "bookmaker": best_odds["draw"]["bookmaker"],
                    "odds": best_odds["draw"]["odds"],
                    "fair_odds": fair_draw_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Draw at odds of {best_odds['draw']['odds']} with {best_odds['draw']['bookmaker']}"
                })
        
        if "away_win" in best_odds and best_odds["away_win"]["odds"] > fair_away_odds:
            edge_percentage = (best_odds["away_win"]["odds"] / fair_away_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Away Win",
                    "bookmaker": best_odds["away_win"]["bookmaker"],
                    "odds": best_odds["away_win"]["odds"],
                    "fair_odds": fair_away_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Away Win at odds of {best_odds['away_win']['odds']} with {best_odds['away_win']['bookmaker']}"
                })
    
    elif "win_prob" in prediction:
        # Horse racing
        fair_win_odds = 100 / prediction["win_prob"] if prediction["win_prob"] > 0 else 999
        fair_place_odds = 100 / prediction["place_prob"] if prediction["place_prob"] > 0 else 999
        
        best_odds = get_best_odds(odds_data)
        
        if "win" in best_odds and best_odds["win"]["odds"] > fair_win_odds:
            edge_percentage = (best_odds["win"]["odds"] / fair_win_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Win",
                    "bookmaker": best_odds["win"]["bookmaker"],
                    "odds": best_odds["win"]["odds"],
                    "fair_odds": fair_win_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Win bet at odds of {best_odds['win']['odds']} with {best_odds['win']['bookmaker']}"
                })
        
        if "place" in best_odds and best_odds["place"]["odds"] > fair_place_odds:
            edge_percentage = (best_odds["place"]["odds"] / fair_place_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Place",
                    "bookmaker": best_odds["place"]["bookmaker"],
                    "odds": best_odds["place"]["odds"],
                    "fair_odds": fair_place_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Place bet at odds of {best_odds['place']['odds']} with {best_odds['place']['bookmaker']}"
                })
    
    else:
        # 2-way market (basketball, volleyball, etc.)
        fair_home_odds = 100 / prediction["home_win_prob"] if prediction["home_win_prob"] > 0 else 999
        fair_away_odds = 100 / prediction["away_win_prob"] if prediction["away_win_prob"] > 0 else 999
        
        best_odds = get_best_odds(odds_data)
        
        if "home_win" in best_odds and best_odds["home_win"]["odds"] > fair_home_odds:
            edge_percentage = (best_odds["home_win"]["odds"] / fair_home_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Home Win",
                    "bookmaker": best_odds["home_win"]["bookmaker"],
                    "odds": best_odds["home_win"]["odds"],
                    "fair_odds": fair_home_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Home Win at odds of {best_odds['home_win']['odds']} with {best_odds['home_win']['bookmaker']}"
                })
        
        if "away_win" in best_odds and best_odds["away_win"]["odds"] > fair_away_odds:
            edge_percentage = (best_odds["away_win"]["odds"] / fair_away_odds - 1) * 100
            if edge_percentage > 5:
                value_bets.append({
                    "bet_type": "Away Win",
                    "bookmaker": best_odds["away_win"]["bookmaker"],
                    "odds": best_odds["away_win"]["odds"],
                    "fair_odds": fair_away_odds,
                    "value_percentage": round(edge_percentage, 1),
                    "description": f"Away Win at odds of {best_odds['away_win']['odds']} with {best_odds['away_win']['bookmaker']}"
                })
    
    # Sort value bets by edge percentage (highest first)
    value_bets.sort(key=lambda x: x["value_percentage"], reverse=True)
    
    return value_bets

def calculate_expected_value(stake, odds, probability):
    """
    Calculate the expected value of a bet
    
    EV = (Probability * (Stake * Odds - Stake)) - ((1 - Probability) * Stake)
    """
    winning_return = stake * (odds - 1)
    expected_value = (probability/100 * winning_return) - ((1 - probability/100) * stake)
    
    return expected_value

def calculate_kelly_stake(bankroll, odds, probability):
    """
    Calculate the optimal stake using the Kelly Criterion
    
    Kelly Stake = Bankroll * ((Probability * (Odds - 1) - (1 - Probability)) / (Odds - 1))
    """
    decimal_probability = probability / 100
    
    # Kelly formula
    kelly = (decimal_probability * (odds - 1) - (1 - decimal_probability)) / (odds - 1)
    
    # Limit the Kelly stake to avoid excessive risk
    # Using "Half Kelly" is a common approach
    kelly = max(0, kelly) * 0.5
    
    # Calculate the stake amount
    stake = bankroll * kelly
    
    return stake, kelly
