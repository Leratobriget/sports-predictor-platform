import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def display_team_stats(team_stats):
    """
    Display team statistics in a visually appealing format
    """
    if not team_stats:
        st.info("No team statistics available")
        return
    
    # Display basic stats as metrics
    if 'team_name' in team_stats:
        st.subheader(f"{team_stats['team_name']} Statistics")
    
    # Display statistics based on sport
    if 'matches_played' in team_stats and 'wins' in team_stats:
        # Soccer/Rugby/Cricket stats
        
        # Win percentage calculation
        if team_stats['matches_played'] > 0:
            win_pct = round((team_stats['wins'] / team_stats['matches_played']) * 100, 1)
        else:
            win_pct = 0
            
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Matches Played", team_stats['matches_played'])
        with col2:
            st.metric("Wins", team_stats['wins'])
        with col3:
            st.metric("Win Rate", f"{win_pct}%")
        
        # Extra metrics specific to some sports
        if 'goals_scored' in team_stats:
            # Soccer specific
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Goals Scored", team_stats['goals_scored'])
            with col2:
                st.metric("Goals Conceded", team_stats['goals_conceded'])
            with col3:
                st.metric("Clean Sheets", team_stats.get('clean_sheets', 0))
        elif 'points_scored' in team_stats and 'points_conceded' in team_stats:
            # Rugby specific
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Points Scored", team_stats['points_scored'])
            with col2:
                st.metric("Points Conceded", team_stats['points_conceded'])
        elif 'batting_avg' in team_stats:
            # Cricket specific
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Batting Average", team_stats['batting_avg'])
            with col2:
                st.metric("Bowling Average", team_stats['bowling_avg'])
        
        # Form visualization
        if 'form' in team_stats and team_stats['form']:
            st.subheader("Recent Form")
            form_data = team_stats['form']
            
            # Create a more visually appealing form display
            html_form = ""
            for result in form_data:
                if result == 'W':
                    html_form += f'<span style="background-color:#28a745;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">W</span>'
                elif result == 'D':
                    html_form += f'<span style="background-color:#ffc107;color:black;padding:2px 8px;border-radius:3px;margin-right:5px;">D</span>'
                elif result == 'L':
                    html_form += f'<span style="background-color:#dc3545;color:white;padding:2px 8px;border-radius:3px;margin-right:5px;">L</span>'
            
            st.markdown(html_form, unsafe_allow_html=True)
            
            # Chart of form as wins/draws/losses distribution
            form_counts = {'Win': form_data.count('W'), 
                          'Draw': form_data.count('D'), 
                          'Loss': form_data.count('L')}
            
            fig = px.pie(values=list(form_counts.values()), 
                        names=list(form_counts.keys()),
                        color=list(form_counts.keys()),
                        color_discrete_map={'Win':'#28a745', 'Draw':'#ffc107', 'Loss':'#dc3545'},
                        hole=0.4)
            fig.update_traces(textinfo='percent+label')
            fig.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=0))
            st.plotly_chart(fig, use_container_width=True)
            
    elif 'games_played' in team_stats and 'wins' in team_stats:
        # Basketball stats
        
        # Win percentage calculation
        win_pct = round((team_stats['wins'] / team_stats['games_played']) * 100, 1)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Games Played", team_stats['games_played'])
        with col2:
            st.metric("Wins", team_stats['wins'])
        with col3:
            st.metric("Win Rate", f"{win_pct}%")
        
        # Basketball specific metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Points Per Game", team_stats['pts_per_game'])
        with col2:
            st.metric("FG %", f"{team_stats['fg_percentage']}%")
        with col3:
            st.metric("3PT %", f"{team_stats['three_pt_percentage']}%")
    
    elif 'horse_name' in team_stats:
        # Horse Racing stats
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Races", team_stats['races'])
        with col2:
            st.metric("Wins", team_stats['wins'])
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Win Rate", f"{team_stats['win_percentage']}%")
        with col2:
            st.metric("In-the-money %", f"{team_stats['in_the_money_percentage']}%")
        
        # Chart of recent finishes
        if 'last_5_finishes' in team_stats:
            st.subheader("Recent Performance")
            
            finishes = team_stats['last_5_finishes']
            
            # Create a bar chart of recent finishes
            fig = px.bar(x=[f"Race {i+1}" for i in range(len(finishes))], 
                        y=[max(11 - finish, 1) for finish in finishes],
                        color=[f"Position {finish}" for finish in finishes],
                        labels={'x': 'Recent Races', 'y': 'Performance (higher is better)'},
                        height=300)
            
            # Invert y-axis to show positions correctly (1st at top)
            fig.update_layout(yaxis=dict(autorange="reversed", title="Position"),
                            margin=dict(l=20, r=20, t=30, b=20))
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Additional race details
            st.markdown(f"**Best Distance:** {team_stats.get('best_distance', 'Unknown')}")
            st.markdown(f"**Jockey:** {team_stats.get('jockey', 'Unknown')}")
            st.markdown(f"**Trainer:** {team_stats.get('trainer', 'Unknown')}")

def compare_team_stats(home_stats, away_stats, match):
    """
    Create a head-to-head comparison of team statistics
    """
    if not home_stats or not away_stats:
        st.info("Insufficient team statistics for comparison")
        return
    
    # For most sports, we compare similar metrics
    if 'matches_played' in home_stats and 'matches_played' in away_stats:
        # Soccer/Rugby/Cricket comparison
        
        # Create comparison data
        home_team = home_stats.get('team_name', match.get('home_team', 'Home Team'))
        away_team = away_stats.get('team_name', match.get('away_team', 'Away Team'))
        
        # Common metrics across these sports
        metrics = []
        
        # Win percentage
        if 'matches_played' in home_stats and home_stats['matches_played'] > 0:
            home_win_pct = round((home_stats['wins'] / home_stats['matches_played']) * 100, 1)
        else:
            home_win_pct = 0
            
        if 'matches_played' in away_stats and away_stats['matches_played'] > 0:
            away_win_pct = round((away_stats['wins'] / away_stats['matches_played']) * 100, 1)
        else:
            away_win_pct = 0
        
        metrics.append({"metric": "Win %", "home": home_win_pct, "away": away_win_pct})
        
        # Sport-specific metrics
        if 'goals_scored' in home_stats and 'goals_scored' in away_stats:
            # Soccer specific
            metrics.append({"metric": "Goals Scored", "home": home_stats['goals_scored'], "away": away_stats['goals_scored']})
            metrics.append({"metric": "Goals Conceded", "home": home_stats['goals_conceded'], "away": away_stats['goals_conceded']})
            
            if 'clean_sheets' in home_stats and 'clean_sheets' in away_stats:
                metrics.append({"metric": "Clean Sheets", "home": home_stats['clean_sheets'], "away": away_stats['clean_sheets']})
                
            if 'xG' in home_stats and 'xG' in away_stats:
                metrics.append({"metric": "Expected Goals", "home": home_stats['xG'], "away": away_stats['xG']})
                
        elif 'points_scored' in home_stats and 'points_scored' in away_stats:
            # Rugby specific
            metrics.append({"metric": "Points Scored", "home": home_stats['points_scored'], "away": away_stats['points_scored']})
            metrics.append({"metric": "Points Conceded", "home": home_stats['points_conceded'], "away": away_stats['points_conceded']})
            
            if 'tries_scored' in home_stats and 'tries_scored' in away_stats:
                metrics.append({"metric": "Tries Scored", "home": home_stats['tries_scored'], "away": away_stats['tries_scored']})
                
        elif 'batting_avg' in home_stats and 'batting_avg' in away_stats:
            # Cricket specific
            metrics.append({"metric": "Batting Average", "home": home_stats['batting_avg'], "away": away_stats['batting_avg']})
            metrics.append({"metric": "Bowling Average", "home": home_stats['bowling_avg'], "away": away_stats['bowling_avg']})
            metrics.append({"metric": "Run Rate", "home": home_stats['run_rate'], "away": away_stats['run_rate']})
        
        # Create a comparison bar chart
        fig = go.Figure()
        
        for i, m in enumerate(metrics):
            fig.add_trace(go.Bar(
                x=[m['home']],
                y=[m['metric']],
                orientation='h',
                name=home_team,
                marker_color='#1E88E5',
                text=[m['home']],
                textposition='outside',
                hoverinfo='text',
                hovertext=f"{home_team}: {m['home']}",
                offsetgroup=0
            ))
            
            fig.add_trace(go.Bar(
                x=[m['away']],
                y=[m['metric']],
                orientation='h',
                name=away_team,
                marker_color='#FF5722',
                text=[m['away']],
                textposition='outside',
                hoverinfo='text',
                hovertext=f"{away_team}: {m['away']}",
                offsetgroup=1
            ))
        
        # Update layout for better visualization
        fig.update_layout(
            barmode='group',
            title=f"{home_team} vs. {away_team} Comparison",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
            margin=dict(l=20, r=20, t=80, b=20),
            height=100 + 60*len(metrics)
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
    elif 'games_played' in home_stats and 'games_played' in away_stats:
        # Basketball comparison
        home_team = home_stats.get('team_name', match.get('home_team', 'Home Team'))
        away_team = away_stats.get('team_name', match.get('away_team', 'Away Team'))
        
        # Basketball-specific metrics
        metrics = []
        
        # Win percentage
        if home_stats['games_played'] > 0:
            home_win_pct = round((home_stats['wins'] / home_stats['games_played']) * 100, 1)
        else:
            home_win_pct = 0
            
        if away_stats['games_played'] > 0:
            away_win_pct = round((away_stats['wins'] / away_stats['games_played']) * 100, 1)
        else:
            away_win_pct = 0
        
        metrics.append({"metric": "Win %", "home": home_win_pct, "away": away_win_pct})
        metrics.append({"metric": "Points/Game", "home": home_stats['pts_per_game'], "away": away_stats['pts_per_game']})
        metrics.append({"metric": "Points Allowed", "home": home_stats['pts_allowed'], "away": away_stats['pts_allowed']})
        metrics.append({"metric": "FG %", "home": home_stats['fg_percentage'], "away": away_stats['fg_percentage']})
        metrics.append({"metric": "3PT %", "home": home_stats['three_pt_percentage'], "away": away_stats['three_pt_percentage']})
        
        if 'rebounds_per_game' in home_stats and 'rebounds_per_game' in away_stats:
            metrics.append({"metric": "Rebounds/Game", "home": home_stats['rebounds_per_game'], "away": away_stats['rebounds_per_game']})
            
        if 'assists_per_game' in home_stats and 'assists_per_game' in away_stats:
            metrics.append({"metric": "Assists/Game", "home": home_stats['assists_per_game'], "away": away_stats['assists_per_game']})
            
        # Create a comparison bar chart (same structure as above)
        fig = go.Figure()
        
        for i, m in enumerate(metrics):
            fig.add_trace(go.Bar(
                x=[m['home']],
                y=[m['metric']],
                orientation='h',
                name=home_team,
                marker_color='#1E88E5',
                text=[m['home']],
                textposition='outside',
                hoverinfo='text',
                hovertext=f"{home_team}: {m['home']}",
                offsetgroup=0
            ))
            
            fig.add_trace(go.Bar(
                x=[m['away']],
                y=[m['metric']],
                orientation='h',
                name=away_team,
                marker_color='#FF5722',
                text=[m['away']],
                textposition='outside',
                hoverinfo='text',
                hovertext=f"{away_team}: {m['away']}",
                offsetgroup=1
            ))
        
        # Update layout for better visualization
        fig.update_layout(
            barmode='group',
            title=f"{home_team} vs. {away_team} Comparison",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
            margin=dict(l=20, r=20, t=80, b=20),
            height=100 + 60*len(metrics)
        )
        
        st.plotly_chart(fig, use_container_width=True)

def plot_historical_matchups(historical_matches):
    """
    Visualize historical matchups between two teams
    """
    if not historical_matches or len(historical_matches) == 0:
        st.info("No historical matchup data available")
        return
    
    # Extract team names to maintain consistency
    home_team = historical_matches[0]['home_team']
    away_team = historical_matches[0]['away_team']
    
    # Prepare data for visualization
    dates = []
    home_scores = []
    away_scores = []
    results = []
    
    for match in historical_matches:
        dates.append(match['date'])
        
        # Handle different score formats
        if isinstance(match['home_score'], (int, float)):
            home_scores.append(match['home_score'])
        else:
            # For cricket-style scores like "285/7", extract the runs
            try:
                home_scores.append(int(match['home_score'].split('/')[0]))
            except:
                home_scores.append(0)
        
        if isinstance(match['away_score'], (int, float)):
            away_scores.append(match['away_score'])
        else:
            try:
                away_scores.append(int(match['away_score'].split('/')[0]))
            except:
                away_scores.append(0)
        
        # Determine the result
        if match['home_team'] == home_team:
            if home_scores[-1] > away_scores[-1]:
                results.append(f"{home_team} won")
            elif home_scores[-1] < away_scores[-1]:
                results.append(f"{away_team} won")
            else:
                results.append("Draw")
        else:
            if home_scores[-1] > away_scores[-1]:
                results.append(f"{match['home_team']} won")
            elif home_scores[-1] < away_scores[-1]:
                results.append(f"{match['away_team']} won")
            else:
                results.append("Draw")
    
    # Create a line chart for score trends
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=dates,
        y=home_scores,
        mode='lines+markers',
        name=home_team,
        line=dict(color='#1E88E5', width=2),
        marker=dict(size=8),
    ))
    
    fig.add_trace(go.Scatter(
        x=dates,
        y=away_scores,
        mode='lines+markers',
        name=away_team,
        line=dict(color='#FF5722', width=2),
        marker=dict(size=8),
    ))
    
    # Update layout
    fig.update_layout(
        title=f"Historical Scores: {home_team} vs {away_team}",
        xaxis_title="Date",
        yaxis_title="Score",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
        margin=dict(l=20, r=20, t=80, b=20),
        hovermode="x unified"
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Summary of historical head-to-head
    st.subheader("Head-to-Head Summary")
    
    # Count results
    home_wins = 0
    away_wins = 0
    draws = 0
    
    for match in historical_matches:
        if match['home_team'] == home_team:
            if match['home_score'] > match['away_score']:
                home_wins += 1
            elif match['home_score'] < match['away_score']:
                away_wins += 1
            else:
                draws += 1
        else:  # Away team is playing at home in this historical match
            if match['home_score'] > match['away_score']:
                away_wins += 1
            elif match['home_score'] < match['away_score']:
                home_wins += 1
            else:
                draws += 1
    
    # Display summary as a pie chart
    labels = [f"{home_team} Wins", f"{away_team} Wins", "Draws"]
    values = [home_wins, away_wins, draws]
    
    fig = px.pie(
        values=values,
        names=labels,
        color=labels,
        color_discrete_map={
            f"{home_team} Wins": '#1E88E5',
            f"{away_team} Wins": '#FF5722',
            "Draws": '#FFC107'
        },
        hole=0.4
    )
    
    fig.update_traces(textinfo='percent+label')
    fig.update_layout(height=300)
    
    col1, col2, col3 = st.columns([2, 6, 2])
    with col2:
        st.plotly_chart(fig, use_container_width=True)

def plot_prediction_accuracy(accuracy_data):
    """
    Visualize prediction accuracy over time
    """
    fig = go.Figure()
    
    # Line chart for accuracy trend
    fig.add_trace(go.Scatter(
        x=[f"Month {i+1}" for i in range(len(accuracy_data['monthly_accuracy']))],
        y=accuracy_data['monthly_accuracy'],
        mode='lines+markers',
        name='Accuracy',
        line=dict(color='#1E88E5', width=3),
        marker=dict(size=10)
    ))
    
    # Update layout
    fig.update_layout(
        title="Prediction Accuracy Trend",
        xaxis_title="Time",
        yaxis_title="Accuracy %",
        yaxis=dict(range=[min(accuracy_data['monthly_accuracy']) - 5, max(accuracy_data['monthly_accuracy']) + 5]),
        margin=dict(l=20, r=20, t=80, b=20),
        hovermode="x unified"
    )
    
    # Add a target line at 70% (considered good for sports predictions)
    fig.add_shape(
        type="line",
        x0=0,
        y0=70,
        x1=len(accuracy_data['monthly_accuracy']) - 1,
        y1=70,
        line=dict(color="green", width=2, dash="dash"),
    )
    
    # Add annotation for the target line
    fig.add_annotation(
        x=0,
        y=70,
        text="Target Accuracy",
        showarrow=False,
        yshift=10,
        font=dict(color="green")
    )
    
    return fig

def plot_sport_accuracy(accuracy_data):
    """
    Visualize prediction accuracy by sport
    """
    sports = list(accuracy_data['sport_accuracy'].keys())
    accuracy_values = list(accuracy_data['sport_accuracy'].values())
    
    # Create bar chart
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=sports,
        y=accuracy_values,
        marker_color='#1E88E5',
        text=accuracy_values,
        texttemplate='%{text:.1f}%',
        textposition='outside',
    ))
    
    # Update layout
    fig.update_layout(
        title="Prediction Accuracy by Sport",
        xaxis_title="Sport",
        yaxis_title="Accuracy %",
        yaxis=dict(range=[min(accuracy_values) - 5, max(accuracy_values) + 5]),
        margin=dict(l=20, r=20, t=80, b=20)
    )
    
    # Add a target line at 70% (considered good for sports predictions)
    fig.add_shape(
        type="line",
        x0=-0.5,
        y0=70,
        x1=len(sports) - 0.5,
        y1=70,
        line=dict(color="green", width=2, dash="dash"),
    )
    
    return fig

def plot_bankroll_growth(bankroll_history):
    """
    Visualize bankroll growth over time
    """
    dates = list(bankroll_history.keys())
    amounts = list(bankroll_history.values())
    
    # Calculate growth percentage
    initial = amounts[0]
    growth_pct = [(amount/initial - 1) * 100 for amount in amounts]
    
    # Create a figure with two y-axes
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    # Add absolute bankroll amount
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=amounts,
            name="Bankroll Amount",
            line=dict(color='#1E88E5', width=3)
        ),
        secondary_y=False
    )
    
    # Add growth percentage
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=growth_pct,
            name="Growth %",
            line=dict(color='#4CAF50', width=2, dash='dot')
        ),
        secondary_y=True
    )
    
    # Update layout
    fig.update_layout(
        title="Bankroll Growth Over Time",
        xaxis_title="Date",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
        margin=dict(l=20, r=20, t=80, b=20),
        hovermode="x unified"
    )
    
    # Set y-axes titles
    fig.update_yaxes(title_text="Bankroll Amount", secondary_y=False)
    fig.update_yaxes(title_text="Growth %", secondary_y=True)
    
    return fig

def plot_kelly_criterion_distribution(kelly_values):
    """
    Visualize Kelly criterion stake sizes
    """
    fig = go.Figure()
    
    # Histogram of Kelly values
    fig.add_trace(go.Histogram(
        x=kelly_values,
        nbinsx=20,
        marker_color='#1E88E5',
        opacity=0.7
    ))
    
    # Add density curve
    if len(kelly_values) > 5:  # Only add density curve if we have enough data points
        bin_size = (max(kelly_values) - min(kelly_values)) / 20
        bin_centers = np.arange(min(kelly_values), max(kelly_values) + bin_size, bin_size)
        kde = np.histogram(kelly_values, bins=20, density=True)[0]
        
        fig.add_trace(go.Scatter(
            x=bin_centers[:-1],
            y=kde,
            mode='lines',
            name='Density',
            line=dict(color='#FF5722', width=3)
        ))
    
    # Update layout
    fig.update_layout(
        title="Distribution of Kelly Criterion Stake Sizes",
        xaxis_title="Kelly Fraction",
        yaxis_title="Frequency",
        margin=dict(l=20, r=20, t=80, b=20)
    )
    
    # Add key regions
    fig.add_shape(
        type="rect",
        x0=-0.1,
        y0=0,
        x1=0,
        y1=1,
        xref="x",
        yref="paper",
        fillcolor="red",
        opacity=0.2,
        layer="below",
        line_width=0,
    )
    
    fig.add_shape(
        type="rect",
        x0=0,
        y0=0,
        x1=0.05,
        y1=1,
        xref="x",
        yref="paper",
        fillcolor="yellow",
        opacity=0.2,
        layer="below",
        line_width=0,
    )
    
    fig.add_shape(
        type="rect",
        x0=0.05,
        y0=0,
        x1=0.2,
        y1=1,
        xref="x",
        yref="paper",
        fillcolor="green",
        opacity=0.2,
        layer="below",
        line_width=0,
    )
    
    fig.add_shape(
        type="rect",
        x0=0.2,
        y0=0,
        x1=1,
        y1=1,
        xref="x",
        yref="paper",
        fillcolor="red",
        opacity=0.2,
        layer="below",
        line_width=0,
    )
    
    return fig
