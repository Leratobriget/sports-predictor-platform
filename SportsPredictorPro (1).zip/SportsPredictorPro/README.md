# Sports Prediction Platform

A multi-sport prediction platform for analyzing game outcomes, comparing odds across sportsbooks, and providing statistical insights with visual data presentation.

![App Screenshot](docs/static/icon-192.png)

## Features

- **Multi-sport Coverage**: Soccer, Basketball, Rugby, Cricket, Volleyball, Horse Racing
- **Prediction Models**: Game outcome predictions with probability analysis
- **Odds Comparison**: Compare odds across multiple sportsbooks
- **Value Betting**: Identify value bets based on our prediction models
- **Historical Analysis**: Review past matchups and team statistics
- **Bankroll Management**: Tools to manage your betting bankroll effectively
- **Mobile-Friendly**: Progressive Web App for installation on mobile devices
- **Notifications**: SMS alerts for betting opportunities (via Twilio)

## Installation

This app has been configured as a Progressive Web App (PWA), which means you can install it on your mobile device without going through an app store:

### For Android Users:
1. Open the app URL in Chrome browser
2. Tap the menu (three dots) in the top right
3. Select "Add to Home Screen"
4. Follow the prompts to install the app

### For iOS Users:
1. Open the app URL in Safari browser
2. Tap the Share button (box with up arrow)
3. Scroll down and select "Add to Home Screen"
4. Follow the prompts to install the app

## Try the App

Visit the live app at [https://Leratobriget.github.io/sports-prediction-platform/](https://Leratobriget.github.io/sports-prediction-platform/)

## Development

This app is built using Streamlit, a Python framework for data applications.

To run it locally:

1. Clone this repository
2. Install dependencies: `pip install -r github_requirements.txt`
3. Run the app: `streamlit run app.py`

## Feedback and Support

For questions or feedback, please open an issue on this repository.