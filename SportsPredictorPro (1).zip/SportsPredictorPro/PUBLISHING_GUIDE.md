# Publishing Your Sports Prediction Platform for Free

This guide will walk you through the process of publishing your Sports Prediction Platform as a mobile app for free, without any app store fees or developer accounts.

## Overview of Free Publishing Methods

You have several free options for publishing your app:

1. **GitHub Pages + PWA** (Recommended)
   - Completely free
   - No developer accounts needed
   - Users can install directly from their browser
   - Works on iOS and Android

2. **Netlify/Vercel + PWA**
   - Similar to GitHub Pages but with additional features
   - Free tiers available
   - Custom domain support

3. **Alternative App Stores**
   - F-Droid (Free, open-source Android app store)
   - Amazon Appstore (Free submission options)

## Method 1: GitHub Pages + PWA (Recommended)

### Step 1: Prepare Your App (Already Done)

The necessary PWA files have already been created:
- Manifest file
- Service worker
- App icons
- HTML wrapper

### Step 2: Create a GitHub Account

1. Go to [GitHub](https://github.com/) and sign up for a free account if you don't already have one

### Step 3: Create a New Repository

1. Click the "+" icon in the top right corner of GitHub
2. Select "New repository"
3. Name your repository (e.g., "sports-prediction-platform")
4. Make it public
5. Click "Create repository"

### Step 4: Upload Your App Files

1. Run the preparation script we created:
   ```
   python prepare_for_github.py
   ```

2. Follow GitHub's instructions to upload your files:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/your-repo-name.git
   git push -u origin main
   ```

### Step 5: Configure GitHub Pages

1. In your GitHub repository, go to "Settings"
2. Scroll down to the "GitHub Pages" section
3. Under "Source", select "main" branch and "/docs" folder
4. Click "Save"
5. Wait a few minutes for your site to be published

### Step 6: Update the App URL

1. Get your GitHub Pages URL (it will be in the format `https://yourusername.github.io/your-repo-name/`)
2. Edit the `docs/index.html` file in your repository
3. Replace `APP_URL_HERE` with your Streamlit app URL (where you've deployed the Streamlit app)
4. Commit and push the changes

### Step 7: Set Up Your Streamlit App for Web Access

You need to deploy your Streamlit app somewhere that's publicly accessible. Free options include:

1. **Streamlit Cloud Free Tier**
   - Go to [Streamlit Cloud](https://streamlit.io/cloud)
   - Connect your GitHub repository
   - Deploy your app for free

2. **Hugging Face Spaces**
   - Free hosting for Streamlit apps
   - Go to [Hugging Face Spaces](https://huggingface.co/spaces)

3. **Render**
   - Has a free tier for web services
   - Supports Python apps

## Method 2: Free App Distribution via F-Droid (Alternative Android App Store)

### Step 1: Package Your App

1. Use [PWA2APK](https://pwa2apk.com/) (free tier available) or [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) (open-source) to convert your PWA to an APK file

### Step 2: Submit to F-Droid

1. Make your app open-source (required for F-Droid)
2. Follow F-Droid submission guidelines at [f-droid.org/docs/Submitting_to_F-Droid_Quick_Start_Guide/](https://f-droid.org/docs/Submitting_to_F-Droid_Quick_Start_Guide/)

## Publishing Updates

To update your app:

1. Make changes to your codebase
2. Run the prepare script again: `python prepare_for_github.py`
3. Commit and push the changes to GitHub
4. Your app will automatically update for all users

## User Installation Instructions (Include These on Your App's Landing Page)

### For Android Users:
1. Open the app URL in Chrome browser
2. Tap the menu (three dots) in the top right
3. Select "Add to Home Screen"
4. Follow the prompts to install the app

### For iOS Users:
1. Open the app URL in Safari browser
2. Tap the Share button (box with up arrow)
3. Scroll down and select "Add to Home Screen"
4. Follow the prompts to install the app